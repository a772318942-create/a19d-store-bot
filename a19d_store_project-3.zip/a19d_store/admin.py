# -*- coding: utf-8 -*-
"""معالجات بوت A19d Store — جزء من المشروع المقسّم."""
from .core import *  # مشاركة الإعدادات والدوال الأساسية مع المعالجات

# ═══════════ لوحة الأدمن ═══════════
@dp.message(Command("admin"))
async def cmd_adm(m:Message):
    if not ia(m.from_user.id): return
    cs(m.from_user.id)
    await m.answer(hd2("لوحة الأدمن","👑") + "\n\n<blockquote>💠 اختر الإجراء</blockquote>",reply_markup=adm_kb())

@dp.callback_query(F.data == "admin")
async def adm(c:CallbackQuery):
    if not ia(c.from_user.id): return
    cs(c.from_user.id)
    await c.message.edit_text(hd2("لوحة الأدمن","👑") + "\n\n<blockquote>💠 اختر الإجراء</blockquote>",reply_markup=adm_kb())

# ═══════════ 📥 استيراد منتجات دفعة واحدة ═══════════
@dp.callback_query(F.data == "impb")
async def impb(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id, "wbulk")
    txt = (hd2("📥 استيراد منتجات (دفعة)", "📦") + "\n\n  <blockquote>📝 أرسل المنتجات، كل منتج في سطر\n\n"
           "<b>الصيغة:</b>\n<code>اسم المنتج | السعر | mc | sc | الوصف | المخزون</code>\n\n"
           "<b>أمثلة:</b>\n"
           "<code>🟢 10 شدات ببجي | 192.92 | gam | pb | شحن فوري</code>\n"
           "<code>📱 رقم واتساب تجريبي | 500 | vnum | wa | وصف المنتج | 3</code>\n"
           "<code>✈️ حساب تلجرام | 1200 | social_acc | tg | حساب مملوك ومصرح ببيعه | 1</code>\n"
           "<code>🐍 كورس Python | 5000 | crs | pg | من الصفر</code>\n\n"
           "⚠️ ملاحظات:\n• mc و sc اختياريان (افتراضي gam/pb)\n"
           "• الأسطر اللي تبدأ بـ # تُتجاهل\n• إذا الاسم موجود، السعر والوصف والمخزون تتحدث\n"
           "• المنتجات العادية: المخزون = -1 افتراضياً\n"
           "• الأرقام والحسابات: المخزون عدد صحيح غير سالب؛ عند حذفه يُسجّل المنتج بمخزون 0\n"
           "• لا تُدرج بيانات دخول أو أرقامًا لا تملك حق بيعها</blockquote>")
    try: await c.message.edit_text(txt, reply_markup=KB([[BTN("❌ إلغاء", "admin", s="danger")]]))
    except: await c.message.answer(txt, reply_markup=KB([[BTN("❌ إلغاء", "admin", s="danger")]]))

# ═══════════ ✏️ تعديل سعر سريع ═══════════
@dp.callback_query(F.data == "edp")
async def edp(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id, "wedp")
    txt = (hd2("✏️ تعديل سعر سريع", "💰") + "\n\n  <blockquote>أرسل: <code>ID السعر_الجديد</code>\n\n<b>مثال:</b> <code>5 1500</code>\n\n💡 لمعرفة IDs المنتجات: <code>/listprods</code></blockquote>")
    try: await c.message.edit_text(txt, reply_markup=KB([[BTN("❌ إلغاء", "admin", s="danger")]]))
    except: await c.message.answer(txt, reply_markup=KB([[BTN("❌ إلغاء", "admin", s="danger")]]))

# ═══════════ أوامر سريعة ═══════════
@dp.message(Command("editprice"))
async def cmd_editprice(m:Message):
    if not ia(m.from_user.id): return
    args = m.text.split()
    if len(args) < 3: await m.answer("⚠️ الاستخدام: <code>/editprice ID السعر</code>"); return
    try: pid = int(args[1]); pr = float(args[2])
    except: await m.answer("⚠️ أرقام فقط"); return
    c2 = db()
    p = c2.execute("SELECT nm FROM prods WHERE id=?", (pid,)).fetchone()
    if not p: c2.close(); await m.answer("❌ المنتج غير موجود"); return
    c2.execute("UPDATE prods SET pr=? WHERE id=?", (pr, pid)); c2.commit(); c2.close()
    await m.answer("✅ تم تعديل سعر: <b>" + p['nm'] + "</b> ➜ " + fm(pr, 'yn'))

@dp.message(Command("listprods"))
async def cmd_listprods(m:Message):
    if not ia(m.from_user.id): return
    c2 = db()
    ps = c2.execute("SELECT id,nm,pr,mc,sc FROM prods ORDER BY id DESC LIMIT 30").fetchall()
    c2.close()
    if not ps: await m.answer("📭 لا توجد منتجات"); return
    t = hd2("📋 قائمة المنتجات", "📦") + "\n\n  <blockquote>"
    for p in ps: t += "🆔 <code>" + str(p['id']) + "</code> | " + p['nm'][:25] + " | " + fm(p['pr'], 'yn') + "\n"
    t += "</blockquote>\n\n💡 <code>/editprice ID السعر</code>"
    await m.answer(t)

@dp.message(Command("delprod"))
async def cmd_delprod(m:Message):
    if not ia(m.from_user.id): return
    args = m.text.split()
    if len(args) < 2: await m.answer("⚠️ الاستخدام: <code>/delprod ID</code>"); return
    try: pid = int(args[1])
    except: await m.answer("⚠️ رقم فقط"); return
    c2 = db()
    p = c2.execute("SELECT nm FROM prods WHERE id=?", (pid,)).fetchone()
    if not p: c2.close(); await m.answer("❌ غير موجود"); return
    c2.execute("DELETE FROM prods WHERE id=?", (pid,)); c2.commit(); c2.close()
    await m.answer("🗑️ تم حذف: <b>" + p['nm'] + "</b>")

# ═══════════ الإحصائيات ═══════════
@dp.callback_query(F.data == "as")
async def as_(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    u = c2.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    p = c2.execute("SELECT COUNT(*) FROM prods").fetchone()[0]
    o = c2.execute("SELECT COUNT(*) FROM ords").fetchone()[0]
    d = c2.execute("SELECT COUNT(*) FROM ords WHERE st='done'").fetchone()[0]
    rv = c2.execute("SELECT SUM(pr) FROM ords WHERE st='done'").fetchone()[0] or 0
    t = datetime.now().strftime('%Y-%m-%d')
    n = c2.execute("SELECT COUNT(*) FROM users WHERE ca LIKE ?",(t+"%",)).fetchone()[0]
    b = c2.execute("SELECT COUNT(*) FROM users WHERE bn=1").fetchone()[0]
    v = c2.execute("SELECT COUNT(*) FROM users WHERE vip=1").fetchone()[0]
    sg = c2.execute("SELECT SUM(amount) FROM stars_log").fetchone()[0] or 0
    sgc = c2.execute("SELECT SUM(stars) FROM stars_log").fetchone()[0] or 0
    c2.close()
    txt = (hd2("الإحصائيات","📊") + "\n\n  <blockquote>👥 المستخدمون: <b>" + str(u) + "</b>\n➕ جديد اليوم: <b>" + str(n) + "</b>\n\n👑 VIP: <b>" + str(v) + "</b>\n🚫 محظور: <b>" + str(b) + "</b>\n\n📦 المنتجات: <b>" + str(p) + "</b>\n🛒 الطلبات: <b>" + str(o) + "</b>\n✅ مكتملة: <b>" + str(d) + "</b>\n\n💰 الأرباح: <b>" + fm(rv,'yn') + "</b>\n⭐ نجوم: <b>" + str(int(sgc)) + "</b> (" + fm(sg,'yn') + ")</blockquote>" + footer(c.from_user.id))
    await c.message.edit_text(txt,reply_markup=KB([[BTN("🔙 رجوع","admin",s="danger")]]))

