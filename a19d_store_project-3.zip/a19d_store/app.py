# -*- coding: utf-8 -*-
"""نقطة تشغيل بوت A19d Store."""
import asyncio
import logging
from . import core
from . import user, shop, admin, admin_products, admin_users, admin_finance, admin_tools, messages

_HANDLER_MODULES = (user, shop, admin, admin_products, admin_users, admin_finance, admin_tools, messages)

def _share_handler_globals():
    """تجعل دوال المعالجات متاحة لبعضها دون تغيير منطق البوت الأصلي."""
    shared = {}
    for module in _HANDLER_MODULES:
        for name, value in vars(module).items():
            if not name.startswith("__") and name not in {"core"}:
                shared[name] = value
    for module in _HANDLER_MODULES:
        module.__dict__.update(shared)

_share_handler_globals()

async def main():
    if not core.T:
        raise RuntimeError("BOT_TOKEN غير موجود. أضف التوكن إلى ملف .env قبل التشغيل.")
    core.init()
    logging.info("A19d Store is starting")
    await core.bot.delete_webhook(drop_pending_updates=True)
    try:
        await core.dp.start_polling(core.bot)
    finally:
        await core.bot.session.close()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    asyncio.run(main())
