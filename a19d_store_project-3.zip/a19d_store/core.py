# -*- coding: utf-8 -*-
import asyncio,sqlite3,logging,os,shutil,random,json
from urllib import error as urlerror, parse as urlparse, request as urlrequest
from datetime import datetime,timedelta
from aiogram import Bot,Dispatcher,F,BaseMiddleware
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command, CommandObject
from aiogram.types import (
    Message,CallbackQuery,InlineKeyboardMarkup,InlineKeyboardButton,
    FSInputFile,ForceReply,ReplyKeyboardMarkup,KeyboardButton,
    LabeledPrice,PreCheckoutQuery
)

# ═══════════ الإعدادات ═══════════
def load_local_env(path=".env"):
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key, value = key.strip(), value.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = value
    except FileNotFoundError:
        pass

load_local_env()

# ═══════════ التوكنات ═══════════
T = os.getenv("BOT_TOKEN", "")
RISE_API_TOKEN = os.getenv("RISE_API_TOKEN", "")
RISE_API_BASE = "https://vnvccv.shop/Ayma/api/v2"
RISE_API_READY = bool(RISE_API_TOKEN)

class RiseApiError(RuntimeError):
    pass

def rise_api_configured():
    return bool(RISE_API_TOKEN)

def _rise_headers():
    if not rise_api_configured():
        raise RiseApiError("توكن Rise API غير مضبوط")
    return {"Authorization": "Bearer " + RISE_API_TOKEN, "Content-Type": "application/json", "Accept": "application/json", "User-Agent": "A19d-Store/1.0"}

def _rise_request_sync(method, params=None, payload=None):
    query = ("?" + urlparse.urlencode(params)) if params else ""
    body = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urlrequest.Request(RISE_API_BASE + query, data=body, headers=_rise_headers(), method=method)
    try:
        with urlrequest.urlopen(req, timeout=20) as response:
            raw = response.read().decode("utf-8", errors="replace")
            data = json.loads(raw) if raw else {}
            if not isinstance(data, dict):
                raise RiseApiError("استجابة Rise API غير مفهومة")
            return data
    except urlerror.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:400]
        raise RiseApiError("Rise API HTTP " + str(exc.code) + ": " + detail) from exc
    except (urlerror.URLError, TimeoutError) as exc:
        raise RiseApiError("تعذر الاتصال بـ Rise API: " + str(exc)) from exc
    except json.JSONDecodeError as exc:
        raise RiseApiError("Rise API أعاد استجابة ليست JSON") from exc

async def rise_catalog(): return await asyncio.to_thread(_rise_request_sync, "GET", {"action": "catalog"})
async def rise_services(): return await asyncio.to_thread(_rise_request_sync, "GET", {"action": "services"})
async def rise_balance(): return await asyncio.to_thread(_rise_request_sync, "GET", {"action": "balance"})
async def rise_order(service_id, quantity, link):
    if not rise_api_configured(): raise RiseApiError("الشراء التلقائي متوقف: ضع RISE_API_TOKEN أولًا")
    return await asyncio.to_thread(_rise_request_sync, "POST", payload={"action": "order", "service_id": int(service_id), "quantity": int(quantity), "link": link})
async def rise_order_status(order_number): return await asyncio.to_thread(_rise_request_sync, "GET", {"action": "order_status", "order_number": str(order_number)})

ADMINS = [8315930004]
CH_U = "@aa_19_d"
CH_URL = "https://t.me/aa_19_d"
LOG_ID = -1003862566124
DEV = "A19ld"
BOT_NAME = "𝐀𝟏𝟗𝐝 𝐒𝐓𝐎𝐑𝐄"
BOT_EMOJI = "💎"
DBF = "a19d.db"

CHANNELS = [{"u": "@aa_19_d", "url": "https://t.me/aa_19_d", "n": "القناة الرسمية"}]

CUR = {
    "yn": ("🇾🇪","ريال يمني قديم","ر.ي قديم",1.0),
    "ys": ("🇾🇪","ريال يمني جديد","ر.ي جديد",3.78),
    "sa": ("🇸🇦","ريال سعودي","ر.س",0.00709),
    "ru": ("🇷🇺","روبل روسي","₽",0.1702),
    "us": ("🇺🇸","دولار أمريكي","$",0.00189),
}
BASE = "yn"

PAY = {
    "jaib": ("💚","محفظة جيب","711611476","أحمد محمد الذيباني"),
    "one": ("💙","ون كاش OneCash","711611476","أحمد محمد الذيباني"),
    "kri": ("💜","كريمي","تواصل مع المطور","—"),
    "bnk": ("🏦","حوالة عبر صراف","تواصل مع المطور","—"),
    "stars": ("⭐","نجوم تلجرام","Telegram Stars","—"),
}

# ═══════════ الأقسام الرئيسية (مع إضافة الأرقام الوهمية) ═══════════
MC = {
    "ai":   ("🤖","الذكاء الاصطناعي","خدمات AI وحسابات"),
    "crs":  ("🎓","كورسات وتعليم","كورسات ودورات"),
    "app":  ("📲","تطبيقات مدفوعة","تطبيقات وبرامج"),
    "vpn":  ("🛡️","حماية وإنترنت","VPN وحماية"),
    "serv": ("🌐","خدمات متنوعة","خدمات رقمية"),
    "ent":  ("🎬","أفلام وموسيقى","منصات المشاهدة"),
    "ofc":  ("💼","أدوات العمل","أدوات إنتاجية"),
    "cld":  ("☁️","تخزين سحابي","مساحات تخزين"),
    "soc":  ("📱","اشتراكات سوشيال","اشتراكات تواصل"),
    "gam":  ("🎮","الألعاب والشحن","شحن الألعاب"),
    "tools":("🛠️","الأدوات والبرامج","أدوات احترافية"),
    "fil":  ("📁","الملفات والبرامج","ملفات متنوعة"),
    "rush": ("⚡","خدمات الرشق","رشق متابعين ولايكات ومشاهدات"),
    "vnum": ("📱","الأرقام الوهمية","أرقام وهمية للتفعيل"),
    "pubg": ("🎯","حسابات ببجي","حسابات ببجي جاهزة"),
    "social_acc": ("👥","حسابات التواصل","حسابات سوشيال جاهزة"),
    "channels": ("📣","بيع القنوات","قنوات ومجتمعات جاهزة"),
    "acc":  ("📦","حسابات جاهزة","حسابات متنوعة"),
}

SC = {
    "ai":   {"all":"📦 كل خدمات AI","ch":"🤖 ChatGPT","gm":"✨ Gemini","cl":"🧠 Claude","mj":"🎨 Midjourney"},
    "crs":  {"pg":"💻 برمجة","ds":"🎨 تصميم","mk":"📈 تسويق","hk":"🔐 أمن واختراق","lang":"🌐 لغات","all":"📦 كل الكورسات"},
    "app":  {"can":"🎨 Canva","cap":"🎬 CapCut","ad":"🎵 Adobe","ms":"📊 Microsoft","all":"📦 كل التطبيقات"},
    "vpn":  {"exp":"⚡ ExpressVPN","nor":"🛡️ NordVPN","sur":"🕵️ Surfshark","all":"📦 كل خدمات VPN"},
    "serv": {"g":"🔍 Google","ms":"💼 Microsoft","ed":"📝 تعليمية","cv":"🖼️ تصميم","wr":"✍️ كتابة","all":"📦 كل الخدمات"},
    "ent":  {"nf":"🎬 Netflix","sh":"📺 Shahid","sp":"🎵 Spotify","yt":"▶️ YouTube","all":"📦 كل المنصات"},
    "ofc":  {"of":"📄 Office 365","tr":"📝 Trello","no":"📝 Notion","all":"📦 كل الأدوات"},
    "cld":  {"gd":"☁️ Google Drive","db":"📦 Dropbox","mg":"☁️ Mega","all":"📦 كل المساحات"},
    "soc":  {"wa":"💚 واتساب","tg":"✈️ تلجرام","ig":"📸 انستقرام","sn":"👻 سناب","fb":"📘 فيسبوك","tt":"🎵 تيك توك","tw":"🐦 تويتر","all":"📦 كل الاشتراكات"},
    "gam":  {"pb":"🔫 ببجي","ff":"🔥 فري فاير","cd":"🎯 كول أوف ديوتي","rb":"🎲 روبلوكس","ml":"⚔️ موبايل ليجند","all":"📦 كل الألعاب"},
    "rush": {"ig":"📸 انستقرام","fb":"📘 فيسبوك","tw":"🐦 تويتر","sn":"👻 سناب","wa":"💚 واتساب","tg":"✈️ تلجرام","fl":"👥 متابعين","lk":"❤️ لايكات","vw":"👁️ مشاهدات","cm":"💬 تعليقات","sh":"📤 مشاركات","all":"📦 كل خدمات الرشق"},
    "vnum": {"wa":"💚 أرقام واتساب جاهزة","tg":"✈️ أرقام تلجرام جاهزة","ig":"📸 أرقام انستقرام","fb":"📘 أرقام فيسبوك","tw":"🐦 أرقام تويتر","all":"📦 كل الأرقام الوهمية"},
    "pubg": {"pubg":"🎯 حسابات ببجي","all":"📦 كل حسابات ببجي"},
    "social_acc": {"fb":"📘 حسابات فيسبوك","ig":"📸 حسابات انستقرام","tt":"🎵 حسابات تيك توك","tw":"🐦 حسابات تويتر","sn":"👻 حسابات سناب","wa":"💚 حسابات واتساب","tg":"✈️ حسابات تلجرام جاهزة","all":"📦 كل حسابات التواصل"},
    "channels": {"tg":"✈️ قنوات تلجرام","yt":"▶️ قنوات يوتيوب","all":"📦 كل القنوات"},
    "tools":{"py":"🐍 بايثون","tm":"📱 ترمكس","kl":"🐉 كالي لينكس","wn":"🪟 ويندوز","all":"📦 كل الأدوات"},
    "fil":  {"ap":"📲 تطبيقات","gf":"🎮 ألعاب","bk":"📚 كتب","all":"📦 كل الملفات"},
    "acc":  {"st":"🛒 متاجر","sn":"📱 سوشيال","stm":"🎮 ستيم","all":"📦 كل الحسابات"},
}

# ═══════════ الثيمات (لتغيير تصميم البوت) ═══════════
THEMES = {
    "diamond": ("💠", "الماسي"),
    "crown":   ("👑", "الملكي"),
    "fire":    ("🔥", "الناري"),
    "star":    ("⭐", "النجمي"),
    "moon":    ("🌙", "القمري"),
    "rocket":  ("🚀", "الصاروخي"),
    "naruto":  ("🍥", "ناروتو — طريق الهوكاغي"),
    "onepiece":("🏴‍☠️", "ون بيس — طاقم القراصنة"),
    "demonslayer":("⚔️", "قاتل الشياطين — الهاشيرا"),
    "jujutsu": ("🔮", "جوجوتسو — الطاقة الملعونة"),
    "dragonball":("🐉", "دراغون بول — القوة القصوى"),
    "titan":   ("🪽", "هجوم العمالقة — الفيلق"),
    "cyber":   ("🌌", "نيون سايبر — المجرة"),
    "phoenix": ("🪽", "العنقاء — العودة الأسطورية"),
}

def get_theme(uid):
    k = st(f"th_{uid}", "diamond")
    return THEMES.get(k, THEMES["diamond"])

def set_theme(uid, key):
    if key in THEMES:
        setst(f"th_{uid}", key)

DHIKR = ["﷽","سبحان الله وبحمده سبحان الله العظيم","لا إله إلا الله وحده لا شريك له","اللهم صلِّ وسلم على نبينا محمد","أستغفر الله العظيم وأتوب إليه","الحمد لله رب العالمين","لا حول ولا قوة إلا بالله","سبحان الله والحمد لله ولا إله إلا الله والله أكبر","اللهم إني أسألك من فضلك ورحمتك","حسبي الله ونعم الوكيل","بسم الله الرحمن الرحيم"]

ACHIEVEMENTS = {1:("🥉","مبتدئ"),5:("🥈","متقدم"),10:("🥇","محترف"),25:("💎","خبير"),50:("👑","أسطورة"),100:("🔥","نخبة البوت")}

bot = Bot(T or "0000000000:AA000000000000000000000000000000000",default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

# ═══════════ قاعدة البيانات ═══════════
def db():
    c = sqlite3.connect(DBF)
    c.row_factory = sqlite3.Row
    return c

def init():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,un TEXT,fn TEXT,cur TEXT,b REAL DEFAULT 0,pt INTEGER DEFAULT 0,rf INTEGER,rc INTEGER DEFAULT 0,bn INTEGER DEFAULT 0,vip INTEGER DEFAULT 0,vr INTEGER DEFAULT 0,wt INTEGER DEFAULT 0,ach TEXT DEFAULT '',ca TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS prods(id INTEGER PRIMARY KEY AUTOINCREMENT,mc TEXT,sc TEXT,nm TEXT,ds TEXT,pr REAL,stk INTEGER DEFAULT -1,img TEXT,vid TEXT,fid TEXT,fname TEXT,lnk TEXT DEFAULT '',sold INTEGER DEFAULT 0,act INTEGER DEFAULT 1,rt REAL DEFAULT 0,rcnt INTEGER DEFAULT 0,ca TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS ords(id INTEGER PRIMARY KEY AUTOINCREMENT,uid INTEGER,pid INTEGER,nm TEXT,pr REAL,st TEXT DEFAULT 'done',ca TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS txs(id INTEGER PRIMARY KEY AUTOINCREMENT,uid INTEGER,am REAL,tp TEXT,ds TEXT,ca TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS cps(cd TEXT PRIMARY KEY,dsc INTEGER,mx INTEGER,us INTEGER DEFAULT 0,act INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS tkts(id INTEGER PRIMARY KEY AUTOINCREMENT,uid INTEGER,msg TEXT,st TEXT DEFAULT 'open',rp TEXT,ca TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY AUTOINCREMENT,pid INTEGER,uid INTEGER,stars INTEGER,comment TEXT,ca TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS states(uid INTEGER PRIMARY KEY,st TEXT,da TEXT);
    CREATE TABLE IF NOT EXISTS admins(user_id INTEGER PRIMARY KEY);
    CREATE TABLE IF NOT EXISTS st(k TEXT PRIMARY KEY,v TEXT);
    CREATE TABLE IF NOT EXISTS favs(uid INTEGER,pid INTEGER,PRIMARY KEY(uid,pid));
    CREATE TABLE IF NOT EXISTS wishlist(id INTEGER PRIMARY KEY AUTOINCREMENT,uid INTEGER,pid INTEGER,notif INTEGER DEFAULT 1,ca TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS stars_log(id INTEGER PRIMARY KEY AUTOINCREMENT,uid INTEGER,stars INTEGER,amount REAL,payload TEXT,ca TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    """)
    for a in ADMINS: c.execute("INSERT OR IGNORE INTO admins VALUES(?)",(a,))
    for k,v in [("mk","100"),("rb","100"),("wb","50"),("db","10"),("vip_price","500"),("vip_days","30"),("star_rate","50")]:
        c.execute("INSERT OR IGNORE INTO st VALUES(?,?)",(k,v))
    for k,(_,_,_,r) in CUR.items():
        c.execute("INSERT OR IGNORE INTO st VALUES(?,?)",("rt_"+k,str(r)))
    c.execute("INSERT OR IGNORE INTO cps VALUES(?,?,?,0,1)",("WELCOME10",10,999))
    c.commit(); c.close()

def gu(uid,un=None,fn=None):
    c = db()
    u = c.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
    if not u:
        c.execute("INSERT INTO users(id,un,fn)VALUES(?,?,?)",(uid,un or '',fn or ''))
        c.commit()
        u = c.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
    elif un or fn:
        c.execute("UPDATE users SET un=?,fn=? WHERE id=?",(un or '',fn or '',uid))
        c.commit()
    c.close()
    return dict(u)

def tx(uid,am,tp,ds):
    c = db(); c.execute("INSERT INTO txs(uid,am,tp,ds)VALUES(?,?,?,?)",(uid,am,tp,ds)); c.commit(); c.close()

def ss(uid,s,d=None):
    c = db(); c.execute("INSERT OR REPLACE INTO states VALUES(?,?,?)",(uid,s,d)); c.commit(); c.close()

def gs(uid):
    c = db(); s = c.execute("SELECT * FROM states WHERE uid=?",(uid,)).fetchone(); c.close()
    return dict(s) if s else None

def cs(uid):
    c = db(); c.execute("DELETE FROM states WHERE uid=?",(uid,)); c.commit(); c.close()

def ia(uid):
    c = db(); r = c.execute("SELECT 1 FROM admins WHERE user_id=?",(uid,)).fetchone(); c.close()
    return bool(r)

def st(k,d=None):
    c = db(); r = c.execute("SELECT v FROM st WHERE k=?",(k,)).fetchone(); c.close()
    return r['v'] if r else d

def setst(k,v):
    c = db(); c.execute("INSERT OR REPLACE INTO st VALUES(?,?)",(k,str(v))); c.commit(); c.close()

def mk(): return float(st("mk","100"))
def rate(k): return float(st("rt_"+k,str(CUR[k][3])))

def fm(a,c=None):
    if not c or c not in CUR: c = BASE
    v = a * rate(c)
    return f"{v:,.2f} {CUR[c][2]}"

def cn(k): return CUR.get(k,("","","",""))[1]

# ═══════════ الأزرار والتصميم ═══════════
def BTN(t,d=None,u=None,s=None):
    if u: return InlineKeyboardButton(text=t,url=u)
    if s:
        try: return InlineKeyboardButton(text=t,callback_data=d,style=s)
        except: return InlineKeyboardButton(text=t,callback_data=d)
    return InlineKeyboardButton(text=t,callback_data=d)

def KB(r): return InlineKeyboardMarkup(inline_keyboard=r)

def srk():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🏠 القائمة الرئيسية")],
            [KeyboardButton(text="👤 حسابي"),KeyboardButton(text="💰 رصيدي")],
            [KeyboardButton(text="🎁 الإحالة"),KeyboardButton(text="🎁 هدية يومية")],
            [KeyboardButton(text="📞 الدعم"),KeyboardButton(text="⭐ المفضلة")],
        ],
        resize_keyboard=True,
        is_persistent=True
    )

def dhikr(): return random.choice(DHIKR)

def hd(t,e=None):
    if not e: e = BOT_EMOJI
    return ("┏━━━━━━━━━━━━━━━┓\n"
            "  " + e + "  <b>" + t + "</b>  " + e + "\n"
            "┗━━━━━━━━━━━━━━━┛")

def hd2(t,e="✨"):
    return ("╔═══════════════════╗\n"
            "  " + e + " <b>" + t + "</b> " + e + "\n"
            "╚═══════════════════╝")

def sep(): return "━━━━━━━━━━━━━━━━━━"
def vb(v): return "👑 <b>VIP</b>" if v else "🔹 عادي"
def vrb(v): return " ✅" if v else ""
def sb(b): return "🚫 محظور" if b else "✅ نشط"

def stars(r):
    n = int(round(r))
    return "⭐"*n + "✩"*(5-n)

def rb():
    return random.choice(["🌺","🌹","🌸","💐","🌷","✨","🌟","💫","⭐","💎","🔮","🌙","☀️","🌈","🎀","🏵️","🌻","🌼","💠"])

def footer(uid=None):
    ic = get_theme(uid)[0] if uid else "💠"
    return "\n\n" + sep() + "\n  " + ic + " " + dhikr() + " " + ic

def ach_txt(cnt):
    b = []
    for n,(e,_) in ACHIEVEMENTS.items():
        if cnt >= n: b.append(e)
    return " ".join(b) if b else "🌟"

def next_ach(cnt):
    for n,(e,name) in ACHIEVEMENTS.items():
        if cnt < n: return e + " " + name + " (" + str(n-cnt) + " طلب)"
    return "👑 أسطورة كاملة!"

def is_fav(uid,pid):
    c = db(); r = c.execute("SELECT 1 FROM favs WHERE uid=? AND pid=?",(uid,pid)).fetchone(); c.close()
    return bool(r)

def toggle_fav(uid,pid):
    c = db()
    r = c.execute("SELECT 1 FROM favs WHERE uid=? AND pid=?",(uid,pid)).fetchone()
    if r:
        c.execute("DELETE FROM favs WHERE uid=? AND pid=?",(uid,pid)); a = False
    else:
        c.execute("INSERT INTO favs VALUES(?,?)",(uid,pid)); a = True
    c.commit(); c.close()
    return a

async def star(c):
    try: await c.answer("⭐")
    except: pass

async def alert(c,text):
    try: await c.answer(text,show_alert=True)
    except: pass

# ═══════════ ✨ القائمة الرئيسية الجديدة (منظمة ومرتبة) ✨ ═══════════
def main_menu(uid,u):
    nm = u['fn'][:20] or "صديقي"
    cur = u.get('cur') or BASE
    fl = CUR[cur][0]
    cur_n = CUR[cur][1]
    bal = fm(u['b'],cur)
    rank = vb(u['vip'])
    vv = vrb(u.get('vr'))
    ic = get_theme(uid)[0]
    
    t = (
        "╔═══════════════════════════╗\n"
        "  " + ic + " <b>" + BOT_NAME + "</b> " + ic + "\n"
        "  <i>ستايل: " + THEMES.get(st(f"th_{uid}", "diamond"), THEMES["diamond"])[1] + "</i>\n"
        "╚═══════════════════════════╝\n\n"
        "  " + ic + " أهلاً <b>" + nm + vv + "</b> " + ic + "\n\n"
        "  ┌─────────────────────┐\n"
        "  │ 👑 الرتبة: " + rank + "\n"
        "  │ 💰 الرصيد: <b>" + bal + "</b>\n"
        "  │ ⭐ النقاط: <b>" + str(u['pt']) + "</b>\n"
        "  │ 💱 العملة: " + fl + " " + cur_n + "\n"
        "  └─────────────────────┘\n\n"
        "  🎨 <i>اختر ما تريد من الأسفل</i>"
        + footer(uid)
    )
    
    r = []
    if ia(uid):
        r.append([BTN("👑 لوحة الأدمن 👑","admin",s="danger")])
    
    # ═══════════════════════════════════════════
    # 🛍️ قسم المنتجات المميزة
    # ═══════════════════════════════════════════
    c2 = db()
    top_ps = c2.execute("SELECT id, nm, pr FROM prods WHERE act=1 ORDER BY sold DESC, id DESC LIMIT 4").fetchall()
    c2.close()
    
    if top_ps:
        r.append([BTN("━━━ 🔥 منتجات مميزة 🔥 ━━━","noop",s="success")])
        row = []
        for p in top_ps:
            price_str = fm(p['pr'] + mk(), cur)
            p_nm = p['nm'][:14] + ".." if len(p['nm']) > 14 else p['nm']
            row.append(BTN(f"📦 {p_nm}\n💰 {price_str}", "pr_" + str(p['id']), s="success"))
            if len(row) == 2:
                r.append(row); row = []
        if row: r.append(row)
    
    # ═══════════════════════════════════════════
    # 🏪 المتجر الرئيسي
    # ═══════════════════════════════════════════
    r.append([BTN("🏪 المتجر الرئيسي 🏪","shop",s="success")])
    
    # ═══════════════════════════════════════════
    # 🌟 المجموعة 1: الخدمات الرقمية
    # ═══════════════════════════════════════════
    r.append([BTN("━━━ 🌟 الخدمات الرقمية ━━━","noop",s="primary")])
    r.append([BTN("🤖 الذكاء الاصطناعي","mc_ai",s="primary"), BTN("🎓 كورسات وتعليم","mc_crs",s="primary")])
    r.append([BTN("📲 تطبيقات مدفوعة","mc_app",s="primary"), BTN("🎬 أفلام وموسيقى","mc_ent",s="primary")])
    r.append([BTN("🛡️ حماية وإنترنت","mc_vpn",s="primary"), BTN("🌐 خدمات متنوعة","mc_serv",s="primary")])
    
    # ═══════════════════════════════════════════
    # ⚡ المجموعة 2: الرشق والأرقام الوهمية
    # ═══════════════════════════════════════════
    r.append([BTN("━━━ ⚡ الرشق والأرقام ━━━","noop",s="success")])
    r.append([BTN("⚡ خدمات الرشق","mc_rush",s="success"), BTN("📱 الأرقام الوهمية","mc_vnum",s="success")])
    r.append([BTN("🎮 الألعاب والشحن","mc_gam",s="success"), BTN("🎯 حسابات ببجي","mc_pubg",s="success")])
    
    # ═══════════════════════════════════════════
    # 👥 المجموعة 3: الحسابات والقنوات
    # ═══════════════════════════════════════════
    r.append([BTN("━━━ 👥 الحسابات والقنوات ━━━","noop",s="primary")])
    r.append([BTN("👥 حسابات سوشيال","mc_social_acc",s="primary"), BTN("📣 بيع القنوات","mc_channels",s="primary")])
    r.append([BTN("📦 حسابات جاهزة","mc_acc",s="primary"), BTN("📱 اشتراكات سوشيال","mc_soc",s="primary")])
    
    # ═══════════════════════════════════════════
    # 🛠️ المجموعة 4: الأدوات والملفات
    # ═══════════════════════════════════════════
    r.append([BTN("━━━ 🛠️ الأدوات والملفات ━━━","noop",s="success")])
    r.append([BTN("🛠️ أدوات وبرامج","mc_tools",s="success"), BTN("📁 ملفات متنوعة","mc_fil",s="success")])
    r.append([BTN("💼 أدوات العمل","mc_ofc",s="success"), BTN("☁️ تخزين سحابي","mc_cld",s="success")])
    
    # ═══════════════════════════════════════════
    # 💼 حسابي
    # ═══════════════════════════════════════════
    r.append([BTN("━━━ 💼 حسابي ━━━","noop",s="primary")])
    r.append([BTN("👤 حسابي","prof",s="primary"), BTN("💰 رصيدي","bal",s="primary")])
    r.append([BTN("📦 طلباتي","myo",s="primary"), BTN("🎁 الإحالة","ref",s="primary")])
    
    # ═══════════════════════════════════════════
    # ⭐ مميزات
    # ═══════════════════════════════════════════
    r.append([BTN("━━━ ⭐ مميزات ━━━","noop",s="success")])
    r.append([BTN("🔥 الأكثر مبيعاً","feat",s="success"), BTN("⭐ الأعلى تقييماً","topt",s="success")])
    r.append([BTN("🎁 هدية يومية","daily",s="success"), BTN("💎 ترقية VIP","vipbuy",s="success")])
    r.append([BTN("🏆 المتصدرون","top",s="primary"), BTN("⭐ المفضلة","favs",s="primary")])
    
    # ═══════════════════════════════════════════
    # ⚙️ الإعدادات والدعم
    # ═══════════════════════════════════════════
    r.append([BTN("━━━ ⚙️ الإعدادات والدعم ━━━","noop",s="primary")])
    r.append([BTN("💱 تغيير العملة","chcur",s="primary"), BTN("🎟️ كوبون","cp",s="primary")])
    r.append([BTN("💳 طرق الدفع","pay",s="success"), BTN("🎨 تصميم البوت","themec",s="success")])
    r.append([BTN("📞 الدعم","sup",s="primary"), BTN("🏆 المتصدرون","top",s="primary")])
    r.append([BTN("📢 القناة", u=CH_URL, s="primary"), BTN("👨‍💻 المطور", u="https://t.me/" + DEV, s="primary")])
    
    # شعار الثيم يظهر أيضًا على الأزرار، حتى يكون التغيير واضحًا بعد الرجوع للرئيسية.
    themed_rows = []
    for row in r:
        themed_row = []
        for button in row:
            label = button.text
            if len(label) + len(ic) + 1 <= 64:
                label = label + " " + ic
            themed_row.append(InlineKeyboardButton(
                text=label, callback_data=button.callback_data, url=button.url,
                style=getattr(button, "style", None)
            ))
        themed_rows.append(themed_row)
    return t, KB(themed_rows)

# ═══════════ قائمة الثيمات ═══════════
def themes_kb(uid):
    current = st(f"th_{uid}", "diamond")
    r = []
    row = []
    for k, (emoji, name) in THEMES.items():
        mark = "✅" if k == current else ""
        row.append(BTN(f"{emoji} {name} {mark}", "thset_" + k, s="success" if k == current else "primary"))
        if len(row) == 2:
            r.append(row); row = []
    if row: r.append(row)
    r.append([BTN("🔙 رجوع","mm",s="danger")])
    return KB(r)

def cur_kb():
    r = []
    for k,(f,n,s,_) in CUR.items():
        r.append([BTN(f+" "+n+" ("+s+")","sc_"+k,s="primary")])
    return KB(r)

def shop_kb():
    r = []
    groups = [
        ("🌟 الخدمات الرقمية", ["ai","crs","app","ent","vpn","serv"], "primary"),
        ("⚡ الرشق والأرقام", ["rush","vnum","gam","pubg"], "success"),
        ("👥 الحسابات والقنوات", ["social_acc","channels","acc","soc"], "primary"),
        ("🛠️ الأدوات والملفات", ["tools","fil","ofc","cld"], "success"),
    ]
    for title, keys, style in groups:
        r.append([BTN("━━━ " + title + " ━━━", "noop", s=style)])
        row = []
        for k in keys:
            e, n, _ = MC[k]
            row.append(BTN(e + " " + n, "mc_" + k, s=style))
            if len(row) == 2:
                r.append(row); row = []
        if row: r.append(row)
    r += [
        [BTN("🔍 بحث سريع", "srch", s="success")],
        [BTN("🔙 رجوع", "mm", s="danger")],
    ]
    return KB(r)

def sc_kb(mc):
    r = []
    for k,n in SC[mc].items():
        r.append([BTN(n,"sc2_"+mc+"_"+k,s="primary")])
    r.append([BTN("🔙 رجوع","shop",s="danger")])
    return KB(r)

def prods_kb(mc,sc,cur,pg=0):
    c = db()
    tot = c.execute("SELECT COUNT(*) FROM prods WHERE mc=? AND sc=? AND act=1",(mc,sc)).fetchone()[0]
    ps = c.execute("SELECT * FROM prods WHERE mc=? AND sc=? AND act=1 LIMIT 6 OFFSET ?",(mc,sc,pg*6)).fetchall()
    c.close()
    r = []
    for p in ps:
        if p['stk'] < 0: qty = "∞"
        elif p['stk'] == 0: qty = "❌"
        else: qty = str(p['stk'])
        price = fm(p['pr']+mk(), cur)
        txt = "📦 " + p['nm'] + " | 📊 " + qty + " | 💰 " + price
        r.append([BTN(txt,"pr_"+str(p['id']),s="success")])
    tp = max(1,(tot+5)//6)
    nv = []
    if pg>0: nv.append(BTN("⬅️","pg_"+mc+"_"+sc+"_"+str(pg-1),s="primary"))
    nv.append(BTN("◈ "+str(pg+1)+"/"+str(tp)+" ◈","noop",s="primary"))
    if pg<tp-1: nv.append(BTN("➡️","pg_"+mc+"_"+sc+"_"+str(pg+1),s="primary"))
    r.append(nv)
    r.append([BTN("🔙 رجوع","mc_"+mc,s="danger")])
    return KB(r)

def adm_kb():
    return KB([
        [BTN("📦 المنتجات","ap",s="primary"),BTN("🛒 الطلبات","ao",s="primary")],
        [BTN("📥 استيراد منتجات","impb",s="success"),BTN("✏️ تعديل سعر","edp",s="primary")],
        [BTN("👥 المستخدمون","au",s="primary"),BTN("📊 الإحصائيات","as",s="success")],
        [BTN("💵 المالية","af",s="primary"),BTN("🎟️ الكوبونات","acp",s="primary")],
        [BTN("📢 البث","abc",s="primary"),BTN("💰 شحن رصيد","ach",s="success")],
        [BTN("💱 أسعار الصرف","art",s="primary"),BTN("⭐ سعر النجمة","asr",s="primary")],
        [BTN("⚙️ الإعدادات","ast",s="primary"),BTN("📢 قنوات الاشتراك","achn",s="primary")],
        [BTN("📝 التذاكر","atk",s="primary"),BTN("🛡️ المشرفين","aad",s="primary")],
        [BTN("💾 نسخة احتياطية","abk",s="primary"),BTN("📋 السجل","alg",s="primary")],
        [BTN("🔙 رجوع للقائمة","mm",s="danger")],
    ])

# ═══════════ Middleware ═══════════
class M(BaseMiddleware):
    async def __call__(self,handler,event,data):
        uid = None
        if isinstance(event,Message): uid = event.from_user.id
        elif isinstance(event,CallbackQuery):
            uid = event.from_user.id
            try: await event.answer("⭐")
            except: pass
        if not uid: return await handler(event,data)
        if ia(uid): return await handler(event,data)
        if isinstance(event,CallbackQuery):
            if event.data == "cj" or event.data.startswith("sc_"): return await handler(event,data)
        u = gu(uid)
        not_joined = []
        for ch in CHANNELS:
            try:
                m = await bot.get_chat_member(ch['u'],uid)
                if m.status in ['left','kicked']: not_joined.append(ch)
            except: not_joined.append(ch)
        if not_joined:
            r = []
            for ch in not_joined: r.append([BTN("📢 "+ch['n'],u=ch['url'],s="primary")])
            r.append([BTN("✅ تحقق من الاشتراك","cj",s="success")])
            t = (hd2("اشتراك إجباري","🔒") + "\n\n"
                 "  <blockquote>عذراً عزيزي،\n"
                 "يجب الاشتراك في القنوات الرسمية\n"
                 "لتتمكن من استخدام البوت " + BOT_EMOJI + "\n\n"
                 "📢 القنوات المطلوبة: <b>" + str(len(not_joined)) + "</b></blockquote>" + footer(uid))
            try:
                if isinstance(event,Message): await event.answer(t,reply_markup=KB(r))
                else: await event.answer("🔒 اشترك أولاً",show_alert=True)
            except: pass
            return
        if not u.get('cur'):
            t = (hd2("اختر عملتك","💱") + "\n\n"
                 "  <blockquote>💠 لكي نعرض لك الأسعار بعملتك\n"
                 "يجب اختيار العملة أولاً\n\n"
                 "⚠️ اختر بحكمة، يمكنك تغييرها لاحقاً</blockquote>" + footer(uid))
            try:
                if isinstance(event,Message): await event.answer(t,reply_markup=cur_kb())
                else: await event.answer("💱 اختر عملتك",show_alert=True)
            except: pass
            return
        return await handler(event,data)

dp.message.middleware(M())
dp.callback_query.middleware(M())

