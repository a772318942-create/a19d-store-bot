# -*- coding: utf-8 -*-
"""معالجات بوت A19d Store — جزء من المشروع المقسّم."""
from .core import *  # مشاركة الإعدادات والدوال الأساسية مع المعالجات

# ═══════════ التذاكر ═══════════
@dp.callback_query(F.data == "atk")
async def atk(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    tks = c2.execute("SELECT * FROM tkts ORDER BY id DESC LIMIT 15").fetchall()
    c2.close()
    if not tks: await alert(c,"📭 لا تذاكر"); return
    r = []
    for t in tks:
        s = "🟢" if t['st']=='open' else "✅"
        r.append([BTN(s+" #"+str(t['id'])+" | "+str(t['uid']),"tk_"+str(t['id']),s="primary")])
    r.append([BTN("🔙 رجوع","admin",s="danger")])
    await c.message.edit_text(hd2("التذاكر","📝") + "\n\n<blockquote>💠 اضغط</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data.startswith("tk_"))
async def tk(c:CallbackQuery):
    if not ia(c.from_user.id): return
    tid = int(c.data[3:])
    c2 = db()
    t = c2.execute("SELECT * FROM tkts WHERE id=?",(tid,)).fetchone()
    c2.close()
    if not t: return
    txt = (hd2("تذكرة #"+str(tid),"📝") + "\n\n  <blockquote>👤 <code>" + str(t['uid']) + "</code>\n\n💬 " + t['msg'] + "</blockquote>")
    await c.message.edit_text(txt,reply_markup=KB([[BTN("✏️ رد","tkr_"+str(tid),s="success")],[BTN("🔙 رجوع","atk",s="danger")]]))

@dp.callback_query(F.data.startswith("tkr_"))
async def tkr(c:CallbackQuery):
    if not ia(c.from_user.id): return
    tid = int(c.data[4:])
    ss(c.from_user.id,"tkr",str(tid))
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("رد","✏️") + "\n\n<blockquote>✍️ أرسل الرد</blockquote>",reply_markup=ForceReply(selective=True))

# ═══════════ البث ═══════════
@dp.callback_query(F.data == "abc")
async def abc(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"abc")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("الإذاعة","📢") + "\n\n<blockquote>✍️ أرسل الرسالة</blockquote>",reply_markup=ForceReply(selective=True))

# ═══════════ شحن رصيد ═══════════
@dp.callback_query(F.data == "ach")
async def ach(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"ach")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("شحن رصيد","💰") + "\n\n<blockquote>✍️ الصيغة:\n<code>ID المبلغ</code></blockquote>",reply_markup=ForceReply(selective=True))

# ═══════════ قنوات الاشتراك ═══════════
@dp.callback_query(F.data == "achn")
async def achn(c:CallbackQuery):
    if not ia(c.from_user.id): return
    t = hd2("قنوات الاشتراك","📢") + "\n\n  <blockquote>"
    for i,ch in enumerate(CHANNELS,1): t += str(i) + ". " + ch['n'] + "\n   <code>" + ch['u'] + "</code>\n\n"
    t += "💡 لتعديل، ابحث عن CHANNELS في الكود</blockquote>"
    await c.message.edit_text(t,reply_markup=KB([[BTN("🔙 رجوع","admin",s="danger")]]))

# ═══════════ المشرفين ═══════════
@dp.callback_query(F.data == "aad")
async def aad(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    ads = c2.execute("SELECT * FROM admins").fetchall()
    c2.close()
    t = hd2("المشرفون","🛡️") + "\n\n  <blockquote>"
    for a in ads:
        u = gu(a['user_id'])
        t += "👑 " + u['fn'] + " | <code>" + str(a['user_id']) + "</code>\n"
    t += "</blockquote>"
    await c.message.edit_text(t,reply_markup=KB([[BTN("➕ إضافة","aad1",s="success")],[BTN("➖ إزالة","aad2",s="danger")],[BTN("🔙 رجوع","admin",s="danger")]]))

@dp.callback_query(F.data == "aad1")
async def aad1(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"aad1")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("إضافة مشرف","➕") + "\n\n<blockquote>✍️ أرسل ID</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data == "aad2")
async def aad2(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"aad2")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("إزالة مشرف","➖") + "\n\n<blockquote>✍️ أرسل ID</blockquote>",reply_markup=ForceReply(selective=True))

# ═══════════ نسخة احتياطية ═══════════
@dp.callback_query(F.data == "abk")
async def abk(c:CallbackQuery):
    if not ia(c.from_user.id): return
    try:
        fn = "bk_" + datetime.now().strftime('%Y%m%d_%H%M%S') + ".db"
        shutil.copy(DBF,fn)
        await c.message.answer_document(FSInputFile(fn),caption="💾 نسخة احتياطية")
        os.remove(fn)
    except: pass

# ═══════════ السجل ═══════════
@dp.callback_query(F.data == "alg")
async def alg(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    ts = c2.execute("SELECT * FROM txs ORDER BY id DESC LIMIT 25").fetchall()
    c2.close()
    t = hd2("سجل الحركات","📋") + "\n\n  <blockquote>"
    for tt in ts:
        s = "🟢" if tt['am']>0 else "🔴"
        t += s + " <code>" + str(tt['uid']) + "</code> | " + tt['ds'][:30] + " | " + fm(tt['am'],'yn') + "\n"
    t += "</blockquote>"
    await c.message.edit_text(t,reply_markup=KB([[BTN("🔙 رجوع","admin",s="danger")]]))

