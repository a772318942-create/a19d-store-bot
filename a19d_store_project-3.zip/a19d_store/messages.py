# -*- coding: utf-8 -*-
"""معالجات بوت A19d Store — جزء من المشروع المقسّم."""
from .core import *  # مشاركة الإعدادات والدوال الأساسية مع المعالجات

# ═══════════ معالجة الرسائل ═══════════
@dp.message(F.text & ~F.text.startswith("/"))
async def on_text(m:Message):
    uid = m.from_user.id
    stt = gs(uid)

    if stt and stt['st'] == 'wbulk':
        if not ia(uid): return
        cs(uid)
        lines = m.text.strip().split("\n")
        added = 0; updated = 0; errors = []
        for i, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith("#"): continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < 2: errors.append(f"سطر {i}: ناقص"); continue
            nm = parts[0]
            try: pr = float(parts[1].replace(",", ""))
            except: errors.append(f"سطر {i}: سعر خطأ"); continue
            mc = parts[2] if len(parts) > 2 and parts[2] in MC else "gam"
            sc = parts[3] if len(parts) > 3 else list(SC[mc].keys())[0]
            if sc not in SC[mc]: sc = list(SC[mc].keys())[0]
            ds = parts[4] if len(parts) > 4 else nm
            limited_stock = mc in {"vnum", "social_acc"}
            default_stock = 0 if limited_stock else -1
            try:
                stock = int(parts[5]) if len(parts) > 5 and parts[5] else default_stock
                if stock < -1 or (limited_stock and stock < 0):
                    raise ValueError
            except ValueError:
                errors.append(f"سطر {i}: المخزون يجب أن يكون عددًا صحيحًا غير سالب للأرقام/الحسابات")
                continue
            c2 = db()
            ex = c2.execute("SELECT id FROM prods WHERE nm=? AND mc=? AND sc=?",(nm,mc,sc)).fetchone()
            if ex:
                c2.execute("UPDATE prods SET pr=?, ds=?, stk=? WHERE id=?",(pr,ds,stock,ex['id'])); updated += 1
            else:
                c2.execute("INSERT INTO prods(mc,sc,nm,ds,pr,stk,lnk) VALUES(?,?,?,?,?,?,?)",(mc,sc,nm,ds,pr,stock,"")); added += 1
            c2.commit(); c2.close()
        res = (hd2("✅ تم الاستيراد","📦") + "\n\n  <blockquote>➕ مضاف: <b>" + str(added) + "</b>\n🔄 محدّث: <b>" + str(updated) + "</b>\n")
        if errors: res += "\n⚠️ أخطاء:\n" + "\n".join(errors[:5])
        res += "</blockquote>"
        await m.answer(res, reply_markup=adm_kb())
        return

    if stt and stt['st'] == 'wedp':
        if not ia(uid): return
        cs(uid)
        parts = m.text.split()
        if len(parts) < 2: await m.answer("⚠️ الصيغة: ID السعر"); return
        try: pid = int(parts[0]); new_price = float(parts[1])
        except: await m.answer("⚠️ أرقام فقط"); return
        c2 = db()
        p = c2.execute("SELECT nm FROM prods WHERE id=?",(pid,)).fetchone()
        if not p: c2.close(); await m.answer("❌ المنتج غير موجود",reply_markup=adm_kb()); return
        c2.execute("UPDATE prods SET pr=? WHERE id=?",(new_price,pid)); c2.commit(); c2.close()
        await m.answer(hd2("✅ تم التعديل","💰") + "\n\n  <blockquote>📦 " + p['nm'] + "\n💰 السعر الجديد: <b>" + fm(new_price,'yn') + "</b></blockquote>", reply_markup=adm_kb())
        return

    if stt and stt['st'] == 'srch':
        cs(uid)
        u = gu(uid)
        cur = u.get('cur') or BASE
        q = "%" + m.text + "%"
        c2 = db()
        ps = c2.execute("SELECT * FROM prods WHERE (nm LIKE ? OR ds LIKE ?) AND act=1 LIMIT 10",(q,q)).fetchall()
        c2.close()
        if not ps:
            await m.answer(hd2("لا نتائج","🔍") + "\n\n<blockquote>💠 لم نجد</blockquote>",reply_markup=KB([[BTN("🔙 رجوع","shop",s="danger")]])); return
        r = []
        for p in ps: r.append([BTN("💠 "+p['nm']+" - "+fm(p['pr']+mk(),cur),"pr_"+str(p['id']),s="success")])
        r.append([BTN("🔙 رجوع","shop",s="danger")])
        await m.answer(hd2("نتائج","🔍") + "\n\n<blockquote>💠 " + str(len(ps)) + " نتيجة</blockquote>",reply_markup=KB(r))
        return
    if stt and stt['st'] == 'cp':
        cs(uid)
        code = m.text.strip().upper()
        c2 = db()
        cp = c2.execute("SELECT * FROM cps WHERE cd=? AND act=1",(code,)).fetchone()
        if not cp or cp['us'] >= cp['mx']:
            c2.close()
            await m.answer(hd2("كود خاطئ","❌") + "\n\n<blockquote>الكوبون غير صالح</blockquote>",reply_markup=KB([[BTN("🔙 رجوع","mm",s="danger")]])); return
        b = cp['dsc']*10
        u = gu(uid)
        cur = u.get('cur') or BASE
        c2.execute("UPDATE users SET b=b+? WHERE id=?",(b,uid))
        c2.execute("UPDATE cps SET us=us+1 WHERE cd=?",(code,))
        c2.commit(); c2.close()
        tx(uid,b,"cp","كوبون "+code)
        await m.answer(hd2("✅ تم تفعيل","🎉") + "\n\n<blockquote>💵 +" + fm(b,cur) + "</blockquote>", reply_markup=KB([[BTN("🛒 تسوق","shop",s="success")],[BTN("🔙 رجوع","mm",s="danger")]]))
        return
    if stt and stt['st'] == 'tk':
        cs(uid)
        c2 = db(); c2.execute("INSERT INTO tkts(uid,msg)VALUES(?,?)",(uid,m.text)); c2.commit(); c2.close()
        await m.answer(hd2("تم الإرسال","✅") + "\n\n<blockquote>💠 سيتم الرد</blockquote>",reply_markup=KB([[BTN("🔙 رجوع","mm",s="danger")]]))
        for a in ADMINS:
            try: await bot.send_message(a, hd2("📩 تذكرة","📩") + "\n\n<blockquote><code>" + str(uid) + "</code>\n\n" + m.text + "</blockquote>")
            except: pass
        return
    if stt and stt['st'] == 'rv_s':
        pid = int(stt['da'])
        parts = m.text.split(maxsplit=1)
        try:
            st_r = int(parts[0])
            if st_r < 1 or st_r > 5: raise ValueError
        except: await m.answer("⚠️ أرسل رقم 1-5"); return
        cmt = parts[1] if len(parts) > 1 else ""
        cs(uid)
        c2 = db()
        c2.execute("INSERT INTO reviews(pid,uid,stars,comment)VALUES(?,?,?,?)",(pid,uid,st_r,cmt))
        avg = c2.execute("SELECT AVG(stars),COUNT(*) FROM reviews WHERE pid=?",(pid,)).fetchone()
        if avg and avg[1] > 0: c2.execute("UPDATE prods SET rt=?,rcnt=? WHERE id=?",(avg[0],avg[1],pid))
        c2.commit(); c2.close()
        await m.answer(hd2("✅ تم التقييم","⭐") + "\n\n<blockquote>" + stars(st_r) + "</blockquote>",reply_markup=KB([[BTN("🔙 رجوع","mm",s="success")]]))
        return
    if not ia(uid) or not stt: return

    if stt['st'] == 'wnm':
        ss(uid,"wds",stt['da']+"|"+m.text)
        try: await m.delete()
        except: pass
        await m.answer(hd2("خطوة 2/6: الوصف","📝") + "\n\n  💠 الاسم: <b>" + m.text + "</b>\n\n  <blockquote>✍️ أرسل الوصف</blockquote>", reply_markup=ForceReply(selective=True))
        return
    if stt['st'] == 'wds':
        ss(uid,"wpr",stt['da']+"|"+m.text)
        try: await m.delete()
        except: pass
        await m.answer(hd2("خطوة 3/6: السعر","💰") + "\n\n  <blockquote>✍️ أرسل السعر بـ الريال اليمني القديم</blockquote>", reply_markup=ForceReply(selective=True))
        return
    if stt['st'] == 'wpr':
        try: float(m.text)
        except: await m.answer("⚠️ رقم"); return
        ss(uid,"wstk",stt['da']+"|"+m.text)
        try: await m.delete()
        except: pass
        await m.answer(hd2("خطوة 4/6: الكمية","📦") + "\n\n  <blockquote>✍️ أرسل الكمية (-1 لبلا حدود)</blockquote>", reply_markup=ForceReply(selective=True))
        return
    if stt['st'] == 'wstk':
        try: int(m.text)
        except: await m.answer("⚠️ رقم"); return
        ss(uid,"wimg",stt['da']+"|"+m.text)
        try: await m.delete()
        except: pass
        await m.answer(hd2("خطوة 5/6: الصورة","🖼️") + "\n\n  <blockquote>💠 أرسل صورة (اختياري)\nأو اضغط تخطي</blockquote>", reply_markup=KB([[BTN("⏭️ تخطي","wsk",s="primary")],[BTN("❌ إلغاء","admin",s="danger")]]))
        return
    if stt['st'] == 'wlnk':
        lnk = "" if m.text.strip() in ("-","لا","تخطي","بدون") else m.text.strip()
        ss(uid,"wvid",stt['da']+"|"+lnk)
        try: await m.delete()
        except: pass
        await m.answer(hd2("خطوة أخيرة: الفيديو","🎬") + "\n\n  <blockquote>💠 الرابط: " + (("✅ " + lnk[:50]) if lnk else "❌ لا يوجد") + "\n\n🎬 أرسل فيديو (اختياري) أو اضغط تخطي</blockquote>", reply_markup=KB([[BTN("⏭️ تخطي الفيديو","wvsk",s="primary")],[BTN("❌ إلغاء","admin",s="danger")]]))
        return
    if stt['st'] == 'wvid': return

    if stt['st'] == 'ert':
        try: r = float(m.text)
        except: await m.answer("⚠️ رقم"); return
        setst("rt_"+stt['da'],r)
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        return
    if stt['st'] == 'epr':
        try: p = float(m.text)
        except: await m.answer("⚠️ رقم"); return
        c2 = db(); c2.execute("UPDATE prods SET pr=? WHERE id=?",(p,int(stt['da']))); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        return
    if stt['st'] == 'est':
        try: s = int(m.text)
        except: await m.answer("⚠️ رقم"); return
        c2 = db()
        c2.execute("UPDATE prods SET stk=? WHERE id=?",(s,int(stt['da'])))
        pid = int(stt['da'])
        ws = c2.execute("SELECT uid FROM wishlist WHERE pid=? AND notif=1",(pid,)).fetchall()
        c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        if s != 0:
            for w in ws:
                try: await bot.send_message(w['uid'], hd2("🔔 توفر منتج","✨") + "\n\n<blockquote>المنتج أصبح متوفراً!</blockquote>")
                except: pass
        return
    if stt['st'] == 'eds':
        c2 = db(); c2.execute("UPDATE prods SET ds=? WHERE id=?",(m.text,int(stt['da']))); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        return
    if stt['st'] == 'enm':
        c2 = db(); c2.execute("UPDATE prods SET nm=? WHERE id=?",(m.text,int(stt['da']))); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        return
    if stt['st'] == 'elnk':
        lnk = "" if m.text.strip() in ("-","لا","بدون") else m.text.strip()
        c2 = db(); c2.execute("UPDATE prods SET lnk=? WHERE id=?",(lnk,int(stt['da']))); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅ تم تحديث الرابط",reply_markup=adm_kb())
        return
    if stt['st'] == 'uc':
        try: a = float(m.text)
        except: await m.answer("⚠️ رقم"); return
        tuid = int(stt['da'])
        c2 = db(); c2.execute("UPDATE users SET b=b+? WHERE id=?",(a,tuid)); c2.commit(); c2.close()
        tx(tuid,a,"adm","شحن إداري")
        u2 = gu(tuid); c2_ = u2.get('cur') or BASE
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        try: await bot.send_message(tuid,hd2("🎁 شحن","💰") + "\n\n<blockquote>💵 +" + fm(a,c2_) + "</blockquote>")
        except: pass
        return
    if stt['st'] == 'up':
        try: p = int(m.text)
        except: await m.answer("⚠️ رقم"); return
        tuid = int(stt['da'])
        c2 = db(); c2.execute("UPDATE users SET pt=pt+? WHERE id=?",(p,tuid)); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        return
    if stt['st'] == 'um':
        tuid = int(stt['da']); cs(uid)
        try:
            await bot.send_message(tuid,hd2("📩 رسالة","📩") + "\n\n<blockquote>" + m.text + "</blockquote>")
            try: await m.delete()
            except: pass
            await m.answer("✅",reply_markup=adm_kb())
        except: await m.answer("❌ فشل",reply_markup=adm_kb())
        return
    if stt['st'] == 'abc':
        cs(uid)
        c2 = db(); us = c2.execute("SELECT id FROM users WHERE bn=0").fetchall(); c2.close()
        ok = 0
        msg = await m.answer("⏳ جاري الإرسال...")
        for i,u in enumerate(us,1):
            try:
                await bot.send_message(u['id'],hd2("📢 إعلان","📢") + "\n\n<blockquote>" + m.text + "</blockquote>"); ok += 1
            except: pass
            if i%20==0:
                try: await msg.edit_text("⏳ " + str(i) + "/" + str(len(us)))
                except: pass
            await asyncio.sleep(0.05)
        await msg.edit_text("✅ تم: " + str(ok) + "/" + str(len(us)))
        return
    if stt['st'] == 'acd':
        p = m.text.split()
        if len(p)<3: await m.answer("⚠️ الصيغة: الكود النسبة الحد"); return
        code = p[0].upper()
        try: d,mx = int(p[1]),int(p[2])
        except: await m.answer("⚠️ أرقام"); return
        c2 = db(); c2.execute("INSERT OR REPLACE INTO cps VALUES(?,?,?,0,1)",(code,d,mx)); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        return
    if stt['st'] == 'tkr':
        tid = int(stt['da'])
        c2 = db()
        t = c2.execute("SELECT * FROM tkts WHERE id=?",(tid,)).fetchone()
        c2.execute("UPDATE tkts SET st='closed',rp=? WHERE id=?",(m.text,tid)); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        try: await bot.send_message(t['uid'],hd2("📩 رد","📩") + "\n\n<blockquote>" + m.text + "</blockquote>")
        except: pass
        return
    if stt['st'] == 'aus':
        cs(uid)
        q = m.text.strip().lstrip('@')
        c2 = db()
        if q.isdigit(): u = c2.execute("SELECT * FROM users WHERE id=?",(int(q),)).fetchone()
        else: u = c2.execute("SELECT * FROM users WHERE un=?",(q,)).fetchone()
        c2.close()
        if not u: await m.answer("❌ غير موجود",reply_markup=adm_kb()); return
        u2 = u['id']
        t = hd2("مستخدم","👤") + "\n\n  <blockquote>👤 " + u['fn'] + "\n🆔 <code>" + str(u2) + "</code>\n💰 " + fm(u['b'],'yn') + "</blockquote>"
        try: await m.delete()
        except: pass
        await m.answer(t,reply_markup=KB([[BTN("💰 شحن","uc_"+str(u2),s="success")],[BTN("🔙 رجوع","au",s="danger")]]))
        return
    if stt['st'] == 'aad1':
        try: aid = int(m.text.strip())
        except: await m.answer("⚠️ رقم"); return
        c2 = db(); c2.execute("INSERT OR IGNORE INTO admins VALUES(?)",(aid,)); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        return
    if stt['st'] == 'aad2':
        try: aid = int(m.text.strip())
        except: await m.answer("⚠️ رقم"); return
        if aid in ADMINS: await m.answer("⚠️ لا يمكن",reply_markup=adm_kb()); cs(uid); return
        c2 = db(); c2.execute("DELETE FROM admins WHERE user_id=?",(aid,)); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        return
    if stt['st'] in ('smk','srb','swb','sdb','svp','ssr'):
        try: v = float(m.text)
        except: await m.answer("⚠️ رقم"); return
        keys = {"smk":"mk","srb":"rb","swb":"wb","sdb":"db","svp":"vip_price","ssr":"star_rate"}
        setst(keys[stt['st']],v)
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅ تم: " + fm(v,'yn'),reply_markup=adm_kb())
        return
    if stt['st'] == 'ach':
        parts = m.text.split()
        if len(parts)<2: await m.answer("⚠️ الصيغة: ID المبلغ"); return
        try: tuid,amt = int(parts[0]),float(parts[1])
        except: await m.answer("⚠️ أرقام"); return
        c2 = db(); c2.execute("UPDATE users SET b=b+? WHERE id=?",(amt,tuid)); c2.commit(); c2.close()
        tx(tuid,amt,"adm","شحن إداري")
        u2 = gu(tuid); c2_ = u2.get('cur') or BASE
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅",reply_markup=adm_kb())
        try: await bot.send_message(tuid,hd2("🎁 شحن","💰") + "\n\n<blockquote>💵 +" + fm(amt,c2_) + "</blockquote>")
        except: pass
        return

# ═══════════ تخطي الصورة → الرابط ═══════════
@dp.callback_query(F.data == "wsk")
async def wsk(c:CallbackQuery):
    uid = c.from_user.id
    stt = gs(uid)
    if not stt: return
    ss(uid,"wlnk",stt['da']+"|")
    await c.message.edit_text(hd2("خطوة 6/6: الرابط","🔗") + "\n\n  <blockquote>💠 أرسل رابط المنتج (اختياري)\n\n📌 مفيد للكورسات والقنوات\nأو اضغط تخطي</blockquote>", reply_markup=KB([[BTN("⏭️ تخطي الرابط","wlsk",s="primary")],[BTN("❌ إلغاء","admin",s="danger")]]))

@dp.callback_query(F.data == "wlsk")
async def wlsk(c:CallbackQuery):
    uid = c.from_user.id
    stt = gs(uid)
    if not stt: return
    parts = stt['da'].split("|")
    new_da = "|".join(parts[:7]) + "||"
    ss(uid,"wvid",new_da)
    await c.message.edit_text(hd2("الفيديو","🎬") + "\n\n  <blockquote>💠 أرسل فيديو (اختياري)\nأو اضغط تخطي</blockquote>", reply_markup=KB([[BTN("⏭️ تخطي الفيديو","wvsk",s="primary")],[BTN("❌ إلغاء","admin",s="danger")]]))

# ═══════════ الصور ═══════════
@dp.message(F.photo)
async def on_photo(m:Message):
    uid = m.from_user.id
    stt = gs(uid)
    if not stt or not ia(uid): return
    if stt['st'] == 'wimg':
        new_da = stt['da'] + "|" + m.photo[-1].file_id
        ss(uid,"wlnk",new_da)
        try: await m.delete()
        except: pass
        await m.answer(hd2("خطوة 6/6: الرابط","🔗") + "\n\n  <blockquote>💠 تم حفظ الصورة ✅\n\nأرسل رابط المنتج (اختياري)\nأو اضغط تخطي</blockquote>", reply_markup=KB([[BTN("⏭️ تخطي","wlsk",s="primary")],[BTN("❌ إلغاء","admin",s="danger")]]))
        return
    if stt['st'] == 'eim':
        pid = int(stt['da'])
        c2 = db(); c2.execute("UPDATE prods SET img=? WHERE id=?",(m.photo[-1].file_id,pid)); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅ تم تحديث الصورة",reply_markup=adm_kb())
        return

# ═══════════ الفيديو ═══════════
@dp.message(F.video)
async def on_video(m:Message):
    uid = m.from_user.id
    stt = gs(uid)
    if not stt or not ia(uid): return
    if stt['st'] == 'wvid':
        new_da = stt['da'] + "|" + m.video.file_id
        ss(uid,"wfl",new_da)
        try: await m.delete()
        except: pass
        await m.answer(hd2("الملف","📎") + "\n\n  <blockquote>💠 تم حفظ الفيديو ✅\n\n📎 أرسل ملف (اختياري) أو اضغط تخطي</blockquote>", reply_markup=KB([[BTN("⏭️ تخطي الملف","wfsk",s="primary")],[BTN("❌ إلغاء","admin",s="danger")]]))
        return
    if stt['st'] == 'evd':
        pid = int(stt['da'])
        c2 = db(); c2.execute("UPDATE prods SET vid=? WHERE id=?",(m.video.file_id,pid)); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅ تم تحديث الفيديو",reply_markup=adm_kb())
        return

# ═══════════ الملفات ═══════════
@dp.message(F.document)
async def on_doc(m:Message):
    uid = m.from_user.id
    stt = gs(uid)
    if not stt or not ia(uid): return
    if stt['st'] == 'wfl':
        parts = stt['da'].split("|")
        while len(parts) < 9: parts.append("")
        mc_,sc_,nm,ds,pr,stk = parts[0],parts[1],parts[2],parts[3],parts[4],parts[5]
        img = parts[6] if parts[6] else None
        lnk = parts[7] if parts[7] else ""
        vid = parts[8] if parts[8] else None
        try: prf = float(pr); stki = int(stk)
        except: await m.answer("⚠️ خطأ"); return
        c2 = db()
        c2.execute("INSERT INTO prods(mc,sc,nm,ds,pr,stk,img,lnk,vid,fid,fname)VALUES(?,?,?,?,?,?,?,?,?,?,?)",(mc_,sc_,nm,ds,prf,stki,img,lnk,vid,m.document.file_id,m.document.file_name or "file"))
        c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer(hd2("✅ تم إضافة المنتج","🎉") + "\n\n<blockquote>📦 " + nm + "\n💰 " + fm(prf,'yn') + "\n🖼️ " + ("✅" if img else "❌") + "\n🔗 " + ("✅" if lnk else "❌") + "\n🎬 " + ("✅" if vid else "❌") + "\n📎 ✅</blockquote>", reply_markup=adm_kb())
        return
    if stt['st'] == 'efl':
        pid = int(stt['da'])
        c2 = db(); c2.execute("UPDATE prods SET fid=?,fname=? WHERE id=?",(m.document.file_id,m.document.file_name or "file",pid)); c2.commit(); c2.close()
        cs(uid)
        try: await m.delete()
        except: pass
        await m.answer("✅ تم تحديث الملف",reply_markup=adm_kb())
        return

# ═══════════ تخطي الفيديو والملف ═══════════
@dp.callback_query(F.data == "wvsk")
async def wvsk(c:CallbackQuery):
    uid = c.from_user.id
    stt = gs(uid)
    if not stt: return
    new_da = stt['da'] + "|"
    ss(uid,"wfl",new_da)
    await c.message.edit_text(hd2("الملف","📎") + "\n\n  <blockquote>💠 أرسل ملف (اختياري) أو اضغط تخطي</blockquote>", reply_markup=KB([[BTN("⏭️ تخطي الملف","wfsk",s="primary")],[BTN("❌ إلغاء","admin",s="danger")]]))

@dp.callback_query(F.data == "wfsk")
async def wfsk(c:CallbackQuery):
    uid = c.from_user.id
    stt = gs(uid)
    if not stt: return
    parts = stt['da'].split("|")
    while len(parts) < 9: parts.append("")
    mc_,sc_,nm,ds,pr,stk = parts[0],parts[1],parts[2],parts[3],parts[4],parts[5]
    img = parts[6] if parts[6] else None
    lnk = parts[7] if parts[7] else ""
    vid = parts[8] if parts[8] else None
    try: prf = float(pr); stki = int(stk)
    except: await c.answer("⚠️ خطأ"); return
    c2 = db()
    c2.execute("INSERT INTO prods(mc,sc,nm,ds,pr,stk,img,lnk,vid)VALUES(?,?,?,?,?,?,?,?,?)",(mc_,sc_,nm,ds,prf,stki,img,lnk,vid))
    c2.commit(); c2.close()
    cs(uid)
    await c.message.edit_text(hd2("✅ تم إضافة المنتج","🎉") + "\n\n<blockquote>📦 " + nm + "\n💰 " + fm(prf,'yn') + "\n🔗 " + ("✅" if lnk else "❌") + "</blockquote>", reply_markup=adm_kb())
