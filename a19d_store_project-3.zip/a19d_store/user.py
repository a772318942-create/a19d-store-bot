# -*- coding: utf-8 -*-
"""معالجات بوت A19d Store — جزء من المشروع المقسّم."""
from .core import *  # مشاركة الإعدادات والدوال الأساسية مع المعالجات

# ═══════════ /start ═══════════
@dp.message(CommandStart())
async def start(m:Message, command: CommandObject):
    args = command.args
    c2 = db()
    ex = c2.execute("SELECT 1 FROM users WHERE id=?",(m.from_user.id,)).fetchone()
    c2.close()
    was_new = not ex
    u = gu(m.from_user.id,m.from_user.username,m.from_user.first_name)
    if args and args.startswith("ref_"):
        try:
            rid = int(args[4:])
            if rid != m.from_user.id and not u['rf']:
                c = db()
                b = float(st("rb","100"))
                c.execute("UPDATE users SET rf=? WHERE id=?",(rid,m.from_user.id))
                c.execute("UPDATE users SET b=b+?,rc=rc+1 WHERE id=?",(b,rid))
                c.commit(); c.close()
                tx(rid,b,"ref","مكافأة إحالة")
                try:
                    await bot.send_message(rid, hd2("🎁 صديق جديد","👥") + "\n\n<blockquote>انضم صديق عبر رابطك!\n💰 ربحت: <b>" + fm(b,u.get('cur') or BASE) + "</b></blockquote>")
                except: pass
        except: pass
    if was_new:
        for a in ADMINS:
            try:
                await bot.send_message(a, hd2("👤 مستخدم جديد","🎉") + "\n\n<blockquote>الاسم: <b>" + m.from_user.first_name + "</b>\nالآيدي: <code>" + str(m.from_user.id) + "</code>\nالمعرف: @" + (m.from_user.username or "لا يوجد") + "</blockquote>")
            except: pass
    u = gu(m.from_user.id)
    if not u.get('wt') and u.get('cur'):
        b = float(st("wb","50"))
        c = db(); c.execute("UPDATE users SET b=b+?,wt=1 WHERE id=?",(b,m.from_user.id)); c.commit(); c.close()
        tx(m.from_user.id,b,"wb","هدية ترحيب")
        try:
            await m.answer(hd2("🎉 مبروك","🎁") + "\n\n<blockquote>💵 حصلت على هدية ترحيب:\n<b>" + fm(b,u['cur']) + "</b>\n\n🎟️ كوبون ترحيبي: <code>WELCOME10</code></blockquote>")
        except: pass
    cs(m.from_user.id)
    u = gu(m.from_user.id)
    t,k = main_menu(m.from_user.id,u)
    await m.answer(t,reply_markup=k)
    await m.answer("✨ اضغط الزر بالأسفل للرجوع في أي وقت 👇",reply_markup=srk())

# ═══════════ أزرار الرد ═══════════
@dp.message(F.text == "🏠 القائمة الرئيسية")
async def home(m:Message):
    cs(m.from_user.id)
    u = gu(m.from_user.id)
    if not u.get('cur'):
        await m.answer(hd2("اختر عملتك","💱") + "\n\n<blockquote>💠 اختر العملة أولاً</blockquote>",reply_markup=cur_kb())
        return
    t,k = main_menu(m.from_user.id,u)
    await m.answer(t,reply_markup=k)

@dp.message(F.text == "👤 حسابي")
async def kb_prof(m:Message): await show_prof(m.from_user.id,m)

@dp.message(F.text == "💰 رصيدي")
async def kb_bal(m:Message): await show_bal(m.from_user.id,m)

@dp.message(F.text == "🎁 الإحالة")
async def kb_ref(m:Message): await show_ref(m.from_user.id,m)

@dp.message(F.text == "📞 الدعم")
async def kb_sup(m:Message):
    ss(m.from_user.id,"tk")
    await m.answer(hd2("الدعم","📞") + "\n\n<blockquote>✍️ أرسل مشكلتك</blockquote>",reply_markup=KB([[BTN("❌ إلغاء","mm",s="danger")]]))

@dp.message(F.text == "🎁 هدية يومية")
async def kb_daily(m:Message): await give_daily(m.from_user.id,m)

@dp.message(F.text == "⭐ المفضلة")
async def kb_favs(m:Message): await show_favs(m.from_user.id,m)

# ═══════════ تحقق الاشتراك ═══════════
@dp.callback_query(F.data == "cj")
async def cj(c:CallbackQuery):
    not_joined = []
    for ch in CHANNELS:
        try:
            m = await bot.get_chat_member(ch['u'],c.from_user.id)
            if m.status in ['left','kicked']: not_joined.append(ch)
        except: not_joined.append(ch)
    if not_joined:
        await alert(c,"❌ لم تشترك في جميع القنوات!"); return
    u = gu(c.from_user.id)
    if not u.get('cur'):
        t = hd2("اختر عملتك","💱") + "\n\n<blockquote>💠 اختر العملة أولاً</blockquote>"
        try: await c.message.edit_text(t,reply_markup=cur_kb())
        except: await c.message.answer(t,reply_markup=cur_kb())
    else:
        t,k = main_menu(c.from_user.id,u)
        try: await c.message.edit_text(t,reply_markup=k)
        except: await c.message.answer(t,reply_markup=k)
    await star(c)

# ═══════════ اختيار العملة ═══════════
@dp.callback_query(F.data.startswith("sc_"))
async def sc(c:CallbackQuery):
    k = c.data[3:]
    if k not in CUR: await star(c); return
    c2 = db(); c2.execute("UPDATE users SET cur=? WHERE id=?",(k,c.from_user.id)); c2.commit(); c2.close()
    u = gu(c.from_user.id)
    if not u.get('wt'):
        b = float(st("wb","50"))
        c2 = db(); c2.execute("UPDATE users SET b=b+?,wt=1 WHERE id=?",(b,c.from_user.id)); c2.commit(); c2.close()
        tx(c.from_user.id,b,"wb","هدية ترحيب")
    u = gu(c.from_user.id)
    t,k = main_menu(c.from_user.id,u)
    try: await c.message.edit_text(t,reply_markup=k)
    except: await c.message.answer(t,reply_markup=k)

# ═══════════ رجوع ═══════════
@dp.callback_query(F.data == "mm")
async def mm(c:CallbackQuery):
    cs(c.from_user.id)
    u = gu(c.from_user.id)
    t,k = main_menu(c.from_user.id,u)
    try: await c.message.edit_text(t,reply_markup=k)
    except: await c.message.answer(t,reply_markup=k)

@dp.callback_query(F.data == "chcur")
async def chcur(c:CallbackQuery):
    await c.message.edit_text(hd2("تغيير العملة","💱") + "\n\n<blockquote>💠 اختر عملتك الجديدة</blockquote>",reply_markup=cur_kb())

@dp.callback_query(F.data == "noop")
async def noop(c:CallbackQuery): pass

# ═══════════ ✨ الثيمات (تصميم البوت) ═══════════
@dp.callback_query(F.data == "themec")
async def themec(c:CallbackQuery):
    uid = c.from_user.id
    cur_theme = st(f"th_{uid}", "diamond")
    t = (
        hd2("🎨 تصميم البوت","✨") + "\n\n"
        "  <blockquote>"
        "💠 اختر الثيم الذي يعجبك\n"
        "سيظهر الثيم على عنوان الرئيسية وزخرفتها وأزرارها\n\n"
        "🎨 الثيم الحالي: <b>" + THEMES.get(cur_theme, THEMES["diamond"])[1] + " " + THEMES.get(cur_theme, THEMES["diamond"])[0] + "</b>"
        "</blockquote>"
        + footer(uid)
    )
    try:
        await c.message.edit_text(t, reply_markup=themes_kb(uid))
    except:
        await c.message.answer(t, reply_markup=themes_kb(uid))

@dp.callback_query(F.data.startswith("thset_"))
async def thset(c:CallbackQuery):
    key = c.data[6:]
    if key not in THEMES: await alert(c,"❌ ثيم غير معروف"); return
    set_theme(c.from_user.id, key)
    uid = c.from_user.id
    await alert(c, f"✅ تم تفعيل ثيم {THEMES[key][1]} {THEMES[key][0]}")
    cur_theme = st(f"th_{uid}", "diamond")
    t = (
        hd2("🎨 تصميم البوت","✨") + "\n\n"
        "  <blockquote>"
        "💠 اختر الثيم الذي يعجبك\n"
        "سيظهر الثيم على عنوان الرئيسية وزخرفتها وأزرارها\n\n"
        "🎨 الثيم الحالي: <b>" + THEMES.get(cur_theme, THEMES["diamond"])[1] + " " + THEMES.get(cur_theme, THEMES["diamond"])[0] + "</b>"
        "</blockquote>"
        + footer(uid)
    )
    try:
        await c.message.edit_text(t, reply_markup=themes_kb(uid))
    except: pass

# ═══════════ VIP ═══════════
@dp.callback_query(F.data == "vipbuy")
async def vipbuy(c:CallbackQuery):
    u = gu(c.from_user.id)
    cur = u.get('cur') or BASE
    price = float(st("vip_price","500"))
    days = int(st("vip_days","30"))
    if u['vip']: await alert(c,"👑 أنت VIP بالفعل!"); return
    t = (hd2("👑 ترقية VIP","💎") + "\n\n"
         "  <blockquote>🎁 ميزات VIP:\n✅ خصم 10% على المنتجات\n✅ شارة VIP مميزة\n✅ هدية يومية مضاعفة\n✅ أولوية في الدعم\n\n"
         "💰 السعر: <b>" + fm(price,cur) + "</b>\n📅 المدة: <b>" + str(days) + " يوم</b></blockquote>" + footer(c.from_user.id))
    await c.message.edit_text(t,reply_markup=KB([[BTN("🛒 اشترِ VIP الآن","vipgo",s="success")],[BTN("🔙 رجوع","mm",s="danger")]]))

@dp.callback_query(F.data == "vipgo")
async def vipgo(c:CallbackQuery):
    u = gu(c.from_user.id)
    cur = u.get('cur') or BASE
    price = float(st("vip_price","500"))
    days = int(st("vip_days","30"))
    if u['vip']: await alert(c,"👑 أنت VIP بالفعل!"); return
    if u['b'] < price: await alert(c,"❌ رصيدك غير كافٍ\nتحتاج: " + fm(price-u['b'],cur)); return
    until = (datetime.now()+timedelta(days=days)).strftime('%Y-%m-%d %H:%M')
    c2 = db(); c2.execute("UPDATE users SET b=b-?,vip=1 WHERE id=?",(price,c.from_user.id)); c2.commit(); c2.close()
    tx(c.from_user.id,-price,"vip","ترقية VIP")
    try:
        await bot.send_message(c.from_user.id, hd2("✅ تم الترقية","👑") + "\n\n<blockquote>مبروك!\nأصبحت VIP حتى: <b>" + until + "</b></blockquote>" + footer(c.from_user.id), reply_markup=KB([[BTN("🏠 الرئيسية","mm",s="success")]]))
    except: pass
    await alert(c,"🎉 مبروك! أصبحت VIP")

# ═══════════ طرق الدفع ═══════════
@dp.callback_query(F.data == "pay")
async def pay(c:CallbackQuery):
    r = []
    for k,(e,n,_,_) in PAY.items():
        r.append([BTN(e+" "+n,"py_"+k,s="primary")])
    r.append([BTN("🔙 رجوع","mm",s="danger")])
    await c.message.edit_text(hd2("طرق الدفع","💳") + "\n\n<blockquote>💠 اختر طريقة الدفع المناسبة\n\n⭐ للدفع بالنجوم اضغط زر النجوم</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data.startswith("py_"))
async def pym(c:CallbackQuery):
    k = c.data[3:]
    if k not in PAY: return
    e,n,num,ow = PAY[k]
    if k == "stars":
        cur_info = gu(c.from_user.id)
        rate_s = float(st("star_rate","50"))
        t = (hd2("⭐ نجوم تلجرام","💫") + "\n\n  <blockquote>💠 اشتري نقاط بالنجوم\n\n⭐ النجمة الواحدة = <b>" + fm(rate_s,'yn') + "</b>\n\nاختر عدد النجوم:</blockquote>" + footer(c.from_user.id))
        r = [
            [BTN("⭐ 50 نجمة","starbuy_50",s="success"),BTN("⭐ 100 نجمة","starbuy_100",s="success")],
            [BTN("⭐ 250 نجمة","starbuy_250",s="success"),BTN("⭐ 500 نجمة","starbuy_500",s="success")],
            [BTN("⭐ 1000 نجمة","starbuy_1000",s="success")],
            [BTN("🔙 رجوع","pay",s="danger")],
        ]
        await c.message.edit_text(t,reply_markup=KB(r))
        return
    t = (hd2("تفاصيل الدفع",e) + "\n\n  💠 <b>" + n + "</b>\n\n  <blockquote>📱 الرقم / الحساب:\n<code>" + num + "</code>\n\n👤 الاسم:\n<b>" + ow + "</b></blockquote>\n\n  ⚠️ <i>بعد التحويل أرسل صورة الإشعار للمطور</i>" + footer(c.from_user.id))
    await c.message.edit_text(t,reply_markup=KB([[BTN("📩 مراسلة المطور",u="https://t.me/"+DEV,s="success")],[BTN("🔙 رجوع","pay",s="danger")]]))

# ═══════════ ⭐ نجوم تلجرام ═══════════
@dp.callback_query(F.data.startswith("starbuy_"))
async def starbuy(c:CallbackQuery):
    try: n_stars = int(c.data[8:])
    except: return
    rate_s = float(st("star_rate","50"))
    total = n_stars * rate_s
    prices = [LabeledPrice(label=f"⭐ {n_stars} نجمة",amount=n_stars)]
    try:
        await bot.send_invoice(chat_id=c.from_user.id,title=f"⭐ شراء {n_stars} نجمة",description=f"احصل على {n_stars} نجمة تُضاف لرصيدك\n(تعادل {fm(total,'yn')})",payload=f"stars_{n_stars}_{c.from_user.id}",provider_token="",currency="XTR",prices=prices)
    except Exception as e:
        try: await c.message.answer("⚠️ خطأ في إنشاء الفاتورة: " + str(e)[:100])
        except: pass

@dp.pre_checkout_query()
async def pre_checkout(q:PreCheckoutQuery):
    try: await q.answer(ok=True)
    except: pass

@dp.message(F.successful_payment)
async def on_success_pay(m:Message):
    sp = m.successful_payment
    stars_amount = sp.total_amount
    payload = sp.invoice_payload
    try: uid = int(payload.split("_")[2])
    except: uid = m.from_user.id
    rate_s = float(st("star_rate","50"))
    money = stars_amount * rate_s
    u = gu(uid)
    cur = u.get('cur') or BASE
    c2 = db()
    c2.execute("UPDATE users SET b=b+? WHERE id=?",(money,uid))
    c2.execute("INSERT INTO stars_log(uid,stars,amount,payload)VALUES(?,?,?,?)",(uid,stars_amount,money,payload))
    c2.commit(); c2.close()
    tx(uid,money,"stars","شراء بالنجوم ⭐")
    try:
        await m.answer(hd2("✅ تم الدفع بنجاح","⭐") + "\n\n<blockquote>⭐ النجوم: <b>" + str(stars_amount) + "</b>\n💰 أُضيف لرصيدك: <b>" + fm(money,cur) + "</b>\n\n🎊 شكراً لك!</blockquote>" + footer(uid), reply_markup=KB([[BTN("🏠 الرئيسية","mm",s="success")]]))
    except: pass
    for a in ADMINS:
        try:
            await bot.send_message(a, hd2("⭐ دفع بالنجوم","💫") + "\n\n<blockquote>👤 <code>" + str(uid) + "</code>\n⭐ النجوم: " + str(stars_amount) + "\n💰 المبلغ: " + fm(money,'yn') + "</blockquote>")
        except: pass

