# -*- coding: utf-8 -*-
"""معالجات بوت A19d Store — جزء من المشروع المقسّم."""
from .core import *  # مشاركة الإعدادات والدوال الأساسية مع المعالجات

# ═══════════ المتجر ═══════════
@dp.callback_query(F.data == "shop")
async def shop(c:CallbackQuery):
    cs(c.from_user.id)
    await c.message.edit_text(hd2("المتجر","🛍️") + "\n\n<blockquote>💠 اختر القسم الرئيسي</blockquote>",reply_markup=shop_kb())

@dp.callback_query(F.data.startswith("mc_"))
async def mc(c:CallbackQuery):
    k = c.data[3:]
    if k not in MC: return
    e,n,d = MC[k]
    await c.message.edit_text(hd2(n,e) + "\n\n<blockquote>" + d + "</blockquote>",reply_markup=sc_kb(k))

@dp.callback_query(F.data.startswith("sc2_"))
async def sc2(c:CallbackQuery):
    p = c.data.split("_",2)
    m,sub = p[1],p[2]
    if m not in SC or sub not in SC[m]: return
    n = SC[m][sub]
    u = gu(c.from_user.id)
    cur = u.get('cur') or BASE
    c2 = db(); cnt = c2.execute("SELECT COUNT(*) FROM prods WHERE mc=? AND sc=? AND act=1",(m,sub)).fetchone()[0]; c2.close()
    if cnt == 0: await alert(c,"📭 لا توجد منتجات حالياً"); return
    await c.message.edit_text(hd2(n,'📦') + "\n\n<blockquote>💠 المنتجات: <b>" + str(cnt) + "</b></blockquote>",reply_markup=prods_kb(m,sub,cur,0))

@dp.callback_query(F.data.startswith("pg_"))
async def pg(c:CallbackQuery):
    p = c.data.split("_",3)
    m,sub,page = p[1],p[2],int(p[3])
    n = SC[m][sub]
    u = gu(c.from_user.id)
    cur = u.get('cur') or BASE
    await c.message.edit_text(hd2(n,'📦') + "\n\n<i>✨ اختر المنتج:</i>",reply_markup=prods_kb(m,sub,cur,page))

@dp.callback_query(F.data.startswith("pr_"))
async def pr(c:CallbackQuery):
    pid = int(c.data[3:])
    c2 = db()
    p = c2.execute("SELECT * FROM prods WHERE id=?",(pid,)).fetchone()
    revs = c2.execute("SELECT * FROM reviews WHERE pid=? ORDER BY id DESC LIMIT 3",(pid,)).fetchall()
    c2.close()
    if not p: await alert(c,"غير موجود"); return
    u = gu(c.from_user.id)
    cur = u.get('cur') or BASE
    f = p['pr'] + mk()
    stk = "♾️ دائماً" if p['stk']<0 else str(p['stk'])
    rt_txt = stars(p['rt']) + " (" + str(p['rcnt']) + ")" if p['rcnt']>0 else "لا تقييمات"
    nm = SC[p['mc']][p['sc']] if p['mc'] in SC and p['sc'] in SC[p['mc']] else p['sc']
    rev_txt = ""
    for r in revs: rev_txt += "\n  " + stars(r['stars']) + " — " + (r['comment'] or "بدون تعليق")[:50]
    if rev_txt: rev_txt = "\n\n  💬 <b>آخر التقييمات:</b>" + rev_txt
    row_btns = []
    if p['lnk']: row_btns.append([BTN("🔗 رابط المنتج",u=p['lnk'],s="primary")])
    row_btns.append([BTN("🛒 اشترِ الآن 🛒","buy_"+str(pid),s="success")])
    fav_b = "💔 إزالة" if is_fav(c.from_user.id,pid) else "❤️ أضف للمفضلة"
    row_btns.append([BTN(fav_b,"fav_"+str(pid),s="primary")])
    row_btns.append([BTN("⭐ قيّم","rv_"+str(pid),s="primary"),BTN("🔔 تنبيهي","wnot_"+str(pid),s="primary")])
    row_btns.append([BTN("🔙 رجوع","sc2_"+p['mc']+"_"+p['sc'],s="danger")])
    cap = (hd2("🛒 تفاصيل المنتج",'📦') + "\n\n  💠 <b>" + p['nm'] + "</b>\n\n  <blockquote>📊 <b>الكمية:</b> " + stk + "\n💰 <b>السعر:</b> " + fm(f,cur) + "\n🔥 <b>المبيعات:</b> " + str(p['sold']) + "\n⭐ <b>التقييم:</b> " + rt_txt + "\n📂 <b>القسم:</b> " + nm + "\n📝 <b>الوصف:</b>\n" + p['ds'] + (("\n\n🔗 الرابط متوفر ✅") if p['lnk'] else "") + "</blockquote>" + rev_txt + footer(c.from_user.id))
    k = KB(row_btns)
    try: await c.message.delete()
    except: pass
    if p['img']:
        try: await c.message.answer_photo(p['img'],caption=cap,reply_markup=k)
        except: await c.message.answer(cap,reply_markup=k)
    else: await c.message.answer(cap,reply_markup=k)

# ═══════════ المفضلة ═══════════
@dp.callback_query(F.data.startswith("fav_"))
async def fav(c:CallbackQuery):
    pid = int(c.data[4:])
    a = toggle_fav(c.from_user.id,pid)
    c.data = "pr_"+str(pid)
    await pr(c)

@dp.callback_query(F.data == "favs")
async def favs(c:CallbackQuery): await show_favs(c.from_user.id,c.message)

async def show_favs(uid,obj):
    c2 = db()
    ps = c2.execute("SELECT p.* FROM prods p JOIN favs f ON p.id=f.pid WHERE f.uid=? AND p.act=1 ORDER BY p.id DESC LIMIT 15",(uid,)).fetchall()
    c2.close()
    u = gu(uid)
    cur = u.get('cur') or BASE
    if not ps:
        await obj.answer(hd2("المفضلة","⭐") + "\n\n<blockquote>💔 لا توجد منتجات\n\nاضغط ❤️ على أي منتج لإضافته</blockquote>",reply_markup=KB([[BTN("🛍️ تسوق","shop",s="success")],[BTN("🔙 رجوع","mm",s="danger")]]))
        return
    r = []
    for p in ps: r.append([BTN("💠 "+p['nm']+" — "+fm(p['pr']+mk(),cur),"pr_"+str(p['id']),s="success")])
    r.append([BTN("🔙 رجوع","mm",s="danger")])
    await obj.answer(hd2("المفضلة","⭐") + "\n\n<blockquote>💠 " + str(len(ps)) + " منتج</blockquote>",reply_markup=KB(r))

# ═══════════ التنبيه عند التوفر ═══════════
@dp.callback_query(F.data.startswith("wnot_"))
async def wnot(c:CallbackQuery):
    pid = int(c.data[5:])
    c2 = db()
    p = c2.execute("SELECT stk FROM prods WHERE id=?",(pid,)).fetchone()
    if not p: c2.close(); return
    ex = c2.execute("SELECT 1 FROM wishlist WHERE uid=? AND pid=?",(c.from_user.id,pid)).fetchone()
    if ex:
        c2.execute("DELETE FROM wishlist WHERE uid=? AND pid=?",(c.from_user.id,pid)); c2.commit(); c2.close()
        await alert(c,"🔕 تم إلغاء التنبيه")
    else:
        c2.execute("INSERT INTO wishlist(uid,pid)VALUES(?,?)",(c.from_user.id,pid)); c2.commit(); c2.close()
        await alert(c,"🔔 سيتم تنبيهك عند توفر المنتج")

# ═══════════ الشراء ═══════════
@dp.callback_query(F.data.startswith("buy_"))
async def buy(c:CallbackQuery):
    pid = int(c.data[4:])
    c2 = db()
    p = c2.execute("SELECT * FROM prods WHERE id=?",(pid,)).fetchone()
    if not p: c2.close(); await alert(c,"غير موجود"); return
    u = gu(c.from_user.id)
    cur = u.get('cur') or BASE
    f = p['pr'] + mk()
    if u['vip']: f = f * 0.9
    if u['bn']: c2.close(); await alert(c,"🚫 أنت محظور"); return
    if u['b'] < f: c2.close(); await alert(c,"❌ رصيدك غير كافٍ\nتحتاج: " + fm(f-u['b'],cur)); return
    if p['stk'] == 0: c2.close(); await alert(c,"❌ نفذت الكمية"); return
    c2.execute("UPDATE users SET b=b-?,vr=1 WHERE id=?",(f,c.from_user.id))
    c2.execute("UPDATE prods SET stk=CASE WHEN stk>0 THEN stk-1 ELSE stk END,sold=sold+1 WHERE id=?",(pid,))
    c2.execute("INSERT INTO ords(uid,pid,nm,pr)VALUES(?,?,?,?)",(c.from_user.id,pid,p['nm'],f))
    c2.commit()
    oid = c2.execute("SELECT last_insert_rowid()").fetchone()[0]
    cnt = c2.execute("SELECT COUNT(*) FROM ords WHERE uid=?",(c.from_user.id,)).fetchone()[0]
    c2.close()
    tx(c.from_user.id,-f,"buy","شراء "+p['nm']+" #"+str(oid))
    new_badge = None
    for n,(e,name) in ACHIEVEMENTS.items():
        if cnt == n: new_badge = (e,name); break
    try:
        await c.message.edit_text(hd2("✅ تم الشراء",'🎉') + "\n\n<blockquote>🧾 #" + str(oid) + "\n📦 " + p['nm'] + "\n💰 " + fm(f,cur) + "\n\n⏳ جاري التسليم...</blockquote>",reply_markup=KB([[BTN("🏠 الرئيسية","mm",s="success")]]))
    except: pass
    if new_badge:
        e,name = new_badge
        try: await bot.send_message(c.from_user.id, hd2("🎖️ إنجاز جديد!",e) + "\n\n<blockquote>مبروك! حصلت على:\n<b>" + e + " " + name + "</b></blockquote>")
        except: pass
    dcap = (hd2("🎁 تم تسليم طلبك",'📦') + "\n\n  <blockquote>🧾 #" + str(oid) + "\n📦 " + p['nm'] + "\n💰 " + fm(f,cur) + "\n\n" + (("🔗 رابط المنتج:\n<code>" + p['lnk'] + "</code>\n\n") if p['lnk'] else "") + "✨ شكراً لثقتك</blockquote>" + footer(c.from_user.id))
    dlv = False
    try:
        if p['fid']:
            try: await bot.send_document(c.from_user.id,p['fid'],caption=dcap,reply_markup=KB([[BTN("🏠","mm",s="success")]])); dlv = True
            except: pass
        if not dlv and p['vid']:
            try: await bot.send_video(c.from_user.id,p['vid'],caption=dcap,reply_markup=KB([[BTN("🏠","mm",s="success")]])); dlv = True
            except: pass
        if not dlv and p['img']:
            try: await bot.send_photo(c.from_user.id,p['img'],caption=dcap,reply_markup=KB([[BTN("🏠","mm",s="success")]])); dlv = True
            except: pass
        if not dlv: await bot.send_message(c.from_user.id,dcap,reply_markup=KB([[BTN("🏠","mm",s="success")]]))
    except: pass
    try:
        me = await bot.get_me()
        lt = (hd2("🛒 عملية شراء",'🔔') + "\n\n  ❁ <b>﷽</b> ❁\n  <i>اللهم صلِّ وسلم على نبينا محمد</i>\n\n  <blockquote>🧾 #" + str(oid) + "\n👤 <b>" + c.from_user.first_name + "</b>\n🆔 <code>" + str(c.from_user.id) + "</code>\n\n📦 " + p['nm'] + "\n💰 " + fm(f,BASE) + "\n📅 " + datetime.now().strftime('%Y-%m-%d %H:%M') + "</blockquote>\n\n  " + sep() + "\n  🤖 @" + me.username + "\n  👨‍💻 @" + DEV)
        await bot.send_message(LOG_ID,lt)
    except: pass
    for a in ADMINS:
        try:
            await bot.send_message(a, hd2("🛒 طلب جديد",'🔔') + "\n\n<blockquote>🧾 #" + str(oid) + "\n👤 " + c.from_user.first_name + "\n🆔 <code>" + str(c.from_user.id) + "</code>\n\n📦 " + p['nm'] + "\n💰 " + fm(f,BASE) + "</blockquote>")
        except: pass

# ═══════════ التقييم ═══════════
@dp.callback_query(F.data.startswith("rv_"))
async def rv(c:CallbackQuery):
    pid = int(c.data[3:])
    ss(c.from_user.id,"rv_s",str(pid))
    await c.message.answer(hd2("تقييم المنتج","⭐") + "\n\n<blockquote>✍️ أرسل التقييم من 1 إلى 5\n\nمثال:\n<code>5 ممتاز</code></blockquote>",reply_markup=ForceReply(selective=True))

# ═══════════ الأكثر مبيعاً ═══════════
@dp.callback_query(F.data == "feat")
async def feat(c:CallbackQuery):
    u = gu(c.from_user.id)
    cur = u.get('cur') or BASE
    c2 = db()
    ps = c2.execute("SELECT * FROM prods WHERE act=1 AND sold>0 ORDER BY sold DESC LIMIT 10").fetchall()
    c2.close()
    if not ps: await alert(c,"📭 لا مبيعات بعد"); return
    r = []
    for i,p in enumerate(ps,1): r.append([BTN("#"+str(i)+" 🔥 "+p['nm']+" — "+fm(p['pr']+mk(),cur),"pr_"+str(p['id']),s="success")])
    r.append([BTN("🔙 رجوع","mm",s="danger")])
    await c.message.edit_text(hd2("الأكثر مبيعاً","🔥") + "\n\n<blockquote>🏆 أفضل 10</blockquote>",reply_markup=KB(r))

# ═══════════ الأعلى تقييماً ═══════════
@dp.callback_query(F.data == "topt")
async def topt(c:CallbackQuery):
    u = gu(c.from_user.id)
    cur = u.get('cur') or BASE
    c2 = db()
    ps = c2.execute("SELECT * FROM prods WHERE act=1 AND rcnt>0 ORDER BY rt DESC,rcnt DESC LIMIT 10").fetchall()
    c2.close()
    if not ps: await alert(c,"📭 لا تقييمات بعد"); return
    r = []
    for i,p in enumerate(ps,1): r.append([BTN("#"+str(i)+" "+stars(p['rt'])+" "+p['nm'][:20],"pr_"+str(p['id']),s="success")])
    r.append([BTN("🔙 رجوع","mm",s="danger")])
    await c.message.edit_text(hd2("الأعلى تقييماً","⭐") + "\n\n<blockquote>🏆 أفضل 10</blockquote>",reply_markup=KB(r))

# ═══════════ المتصدرون ═══════════
@dp.callback_query(F.data == "top")
async def top(c:CallbackQuery):
    u_me = gu(c.from_user.id)
    myc = u_me.get('cur') or BASE
    c2 = db()
    us = c2.execute("SELECT id,fn,b,vr FROM users WHERE bn=0 ORDER BY b DESC LIMIT 10").fetchall()
    c2.close()
    t = hd2("المتصدرون","🏆") + "\n\n  <blockquote>"
    md = ["🥇","🥈","🥉"]
    for i,u in enumerate(us):
        m = md[i] if i<3 else "#"+str(i+1)
        bd = " ✅" if u['vr'] else ""
        t += m + " <b>" + u['fn'] + "</b>" + bd + " — " + fm(u['b'],myc) + "\n"
    t += "</blockquote>" + footer(c.from_user.id)
    await c.message.edit_text(t,reply_markup=KB([[BTN("🔙 رجوع","mm",s="danger")]]))

# ═══════════ البحث ═══════════
@dp.callback_query(F.data == "srch")
async def srch(c:CallbackQuery):
    ss(c.from_user.id,"srch")
    await c.message.edit_text(hd2("البحث","🔍") + "\n\n<blockquote>✍️ أرسل اسم المنتج</blockquote>",reply_markup=KB([[BTN("❌ إلغاء","shop",s="danger")]]))

# ═══════════ حسابي ═══════════
async def show_prof(uid,obj):
    u = gu(uid)
    cur = u.get('cur') or BASE
    c2 = db()
    oc = c2.execute("SELECT COUNT(*) FROM ords WHERE uid=?",(uid,)).fetchone()[0]
    c2.close()
    t = (hd2("ملفي","👤") + "\n\n  💠 الاسم: <b>" + u['fn'] + vrb(u.get('vr')) + "</b>\n  💠 الآيدي: <code>" + str(u['id']) + "</code>\n  💠 العملة: " + CUR[cur][0] + " <b>" + CUR[cur][1] + "</b>\n\n  <blockquote>👑 الرتبة: " + vb(u['vip']) + "\n💰 الرصيد: <b>" + fm(u['b'],cur) + "</b>\n⭐ النقاط: <b>" + str(u['pt']) + "</b>\n🎁 الإحالات: <b>" + str(u['rc']) + "</b>\n📦 الطلبات: <b>" + str(oc) + "</b>\n🎖️ الشارات: " + ach_txt(oc) + "\n🎯 التالي: " + next_ach(oc) + "\n📊 الحالة: " + sb(u['bn']) + "</blockquote>" + footer(uid))
    await obj.answer(t,reply_markup=KB([[BTN("🔙 رجوع","mm",s="danger")]]))

@dp.callback_query(F.data == "prof")
async def prof_cb(c:CallbackQuery): await show_prof(c.from_user.id,c.message)

# ═══════════ رصيدي ═══════════
async def show_bal(uid,obj):
    u = gu(uid)
    cur = u.get('cur') or BASE
    c2 = db()
    txs = c2.execute("SELECT * FROM txs WHERE uid=? ORDER BY id DESC LIMIT 5",(uid,)).fetchall()
    c2.close()
    tt = ""
    for t in txs:
        sg = "🟢" if t['am']>0 else "🔴"
        tt += "  " + sg + " " + t['ds'] + " | " + fm(abs(t['am']),cur) + "\n"
    if not tt: tt = "  <i>لا توجد معاملات</i>"
    t = (hd2("رصيدي","💰") + "\n\n  <blockquote>💵 <b>" + fm(u['b'],cur) + "</b></blockquote>\n\n  <b>📋 آخر المعاملات:</b>\n" + tt + footer(uid))
    await obj.answer(t,reply_markup=KB([[BTN("💳 طرق الدفع","pay",s="success")],[BTN("🔙 رجوع","mm",s="danger")]]))

@dp.callback_query(F.data == "bal")
async def bal_cb(c:CallbackQuery): await show_bal(c.from_user.id,c.message)

# ═══════════ طلباتي ═══════════
@dp.callback_query(F.data == "myo")
async def myo(c:CallbackQuery):
    u = gu(c.from_user.id)
    cur = u.get('cur') or BASE
    c2 = db()
    os_ = c2.execute("SELECT * FROM ords WHERE uid=? ORDER BY id DESC LIMIT 10",(c.from_user.id,)).fetchall()
    c2.close()
    if not os_: await alert(c,"📭 لا توجد طلبات"); return
    sm = {"pending":"⏳","done":"✅","cancelled":"❌"}
    t = hd2("طلباتي","📦") + "\n\n"
    for o in os_: t += "  " + sm.get(o['st'],'⏳') + " <b>#" + str(o['id']) + "</b> - " + o['nm'][:25] + " | " + fm(o['pr'],cur) + "\n"
    t += footer(c.from_user.id)
    await c.message.edit_text(t,reply_markup=KB([[BTN("🔙 رجوع","mm",s="danger")]]))

# ═══════════ الإحالة ═══════════
async def show_ref(uid,obj):
    me = await bot.get_me()
    lk = "https://t.me/" + me.username + "?start=ref_" + str(uid)
    u = gu(uid)
    cur = u.get('cur') or BASE
    b = float(st("rb","100"))
    t = (hd2("الإحالات","🎁") + "\n\n  <blockquote>💠 مكافأة لكل صديق: <b>" + fm(b,cur) + "</b>\n👥 إحالاتك: <b>" + str(u['rc']) + "</b></blockquote>\n\n  🔗 <b>رابطك:</b>\n<code>" + lk + "</code>" + footer(uid))
    await obj.answer(t,reply_markup=KB([[BTN("📤 مشاركة",u="https://t.me/share/url?url="+lk+"&text=انضم لأفضل بوت!",s="success")],[BTN("🔙 رجوع","mm",s="danger")]]))

@dp.callback_query(F.data == "ref")
async def ref_cb(c:CallbackQuery): await show_ref(c.from_user.id,c.message)

# ═══════════ كوبون ═══════════
@dp.callback_query(F.data == "cp")
async def cp(c:CallbackQuery):
    ss(c.from_user.id,"cp")
    await c.message.edit_text(hd2("كوبون","🎟️") + "\n\n<blockquote>✍️ أرسل كود الكوبون</blockquote>",reply_markup=KB([[BTN("❌ إلغاء","mm",s="danger")]]))

# ═══════════ الدعم ═══════════
@dp.callback_query(F.data == "sup")
async def sup(c:CallbackQuery):
    ss(c.from_user.id,"tk")
    await c.message.edit_text(hd2("الدعم","📞") + "\n\n<blockquote>✍️ أرسل مشكلتك</blockquote>",reply_markup=KB([[BTN("❌ إلغاء","mm",s="danger")]]))

# ═══════════ الهدية اليومية ═══════════
@dp.callback_query(F.data == "daily")
async def daily(c:CallbackQuery): await give_daily(c.from_user.id,c.message)

async def give_daily(uid,obj):
    u = gu(uid)
    today = datetime.now().strftime('%Y-%m-%d')
    if u['ach'] == today:
        await obj.answer(hd2("🎁 هدية يومية","✨") + "\n\n<blockquote>💔 أخذت هديتك اليوم!\n\n⏰ عد غداً</blockquote>",reply_markup=KB([[BTN("🏠","mm",s="success")]]))
        return
    b = float(st("db","10"))
    if u['vip']: b = b * 2
    cur = u.get('cur') or BASE
    c2 = db(); c2.execute("UPDATE users SET b=b+?,ach=? WHERE id=?",(b,today,uid)); c2.commit(); c2.close()
    tx(uid,b,"daily","هدية يومية")
    note = " (مضاعفة VIP 👑)" if u['vip'] else ""
    await obj.answer(hd2("🎁 هدية يومية","✨") + "\n\n<blockquote>💵 حصلت على:\n<b>" + fm(b,cur) + "</b>" + note + "\n\n🎊 عد غداً</blockquote>" + footer(uid), reply_markup=KB([[BTN("🏠","mm",s="success")]]))

