# -*- coding: utf-8 -*-
"""معالجات بوت A19d Store — جزء من المشروع المقسّم."""
from .core import *  # مشاركة الإعدادات والدوال الأساسية مع المعالجات

# ═══════════ الطلبات ═══════════
@dp.callback_query(F.data == "ao")
async def ao(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    os_ = c2.execute("SELECT * FROM ords ORDER BY id DESC LIMIT 15").fetchall()
    c2.close()
    if not os_: await alert(c,"📭 لا طلبات"); return
    r = []
    for o in os_: r.append([BTN("#"+str(o['id'])+" | "+o['nm'][:20],"or_"+str(o['id']),s="primary")])
    r.append([BTN("🔙 رجوع","admin",s="danger")])
    await c.message.edit_text(hd2("الطلبات","🛒") + "\n\n<blockquote>💠 اضغط</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data.startswith("or_"))
async def or_(c:CallbackQuery):
    if not ia(c.from_user.id): return
    oid = int(c.data[3:])
    c2 = db()
    o = c2.execute("SELECT * FROM ords WHERE id=?",(oid,)).fetchone()
    c2.close()
    if not o: return
    t = (hd2("طلب #"+str(oid),"🛒") + "\n\n  <blockquote>👤 <code>" + str(o['uid']) + "</code>\n📦 " + o['nm'] + "\n💰 " + fm(o['pr'],'yn') + "\n📅 " + o['ca'][:16] + "</blockquote>")
    await c.message.edit_text(t,reply_markup=KB([[BTN("🔙 رجوع","ao",s="danger")]]))

# ═══════════ المالية ═══════════
@dp.callback_query(F.data == "af")
async def af(c:CallbackQuery):
    if not ia(c.from_user.id): return
    await c.message.edit_text(hd2("المالية","💵") + "\n\n<blockquote>💠 اختر</blockquote>",reply_markup=KB([[BTN("💰 شحن يدوي","ach",s="success")],[BTN("📊 التقرير المالي","afr",s="primary")],[BTN("📋 آخر المعاملات","aft",s="primary")],[BTN("⭐ سجل النجوم","astr",s="primary")],[BTN("🔙 رجوع","admin",s="danger")]]))

@dp.callback_query(F.data == "afr")
async def afr(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    ti = c2.execute("SELECT SUM(am) FROM txs WHERE am>0").fetchone()[0] or 0
    to = c2.execute("SELECT SUM(am) FROM txs WHERE am<0").fetchone()[0] or 0
    c2.close()
    t = (hd2("التقرير المالي","📊") + "\n\n  <blockquote>📈 إيداع: <b>" + fm(ti,'yn') + "</b>\n📉 خصم: <b>" + fm(abs(to),'yn') + "</b>\n💰 الصافي: <b>" + fm(ti+to,'yn') + "</b></blockquote>")
    await c.message.edit_text(t,reply_markup=KB([[BTN("🔙 رجوع","af",s="danger")]]))

@dp.callback_query(F.data == "aft")
async def aft(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    ts = c2.execute("SELECT * FROM txs ORDER BY id DESC LIMIT 20").fetchall()
    c2.close()
    t = hd2("المعاملات","📋") + "\n\n  <blockquote>"
    for tt in ts:
        s = "🟢" if tt['am']>0 else "🔴"
        t += s + " <code>" + str(tt['uid']) + "</code> | " + fm(tt['am'],'yn') + "\n"
    t += "</blockquote>"
    await c.message.edit_text(t,reply_markup=KB([[BTN("🔙 رجوع","af",s="danger")]]))

@dp.callback_query(F.data == "astr")
async def astr(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    ss_ = c2.execute("SELECT * FROM stars_log ORDER BY id DESC LIMIT 20").fetchall()
    tot = c2.execute("SELECT SUM(stars) FROM stars_log").fetchone()[0] or 0
    c2.close()
    t = hd2("سجل النجوم","⭐") + "\n\n  <blockquote>📊 إجمالي النجوم: <b>" + str(int(tot)) + "</b>\n\n"
    for x in ss_: t += "⭐ " + str(x['stars']) + " | <code>" + str(x['uid']) + "</code> | " + x['ca'][:16] + "\n"
    t += "</blockquote>"
    await c.message.edit_text(t,reply_markup=KB([[BTN("🔙 رجوع","af",s="danger")]]))

# ═══════════ الإعدادات ═══════════
@dp.callback_query(F.data == "ast")
async def ast(c:CallbackQuery):
    if not ia(c.from_user.id): return
    txt = (hd2("الإعدادات","⚙️") + "\n\n  <blockquote>💵 هامش الربح: <b>" + fm(mk(),'yn') + "</b>\n🎁 مكافأة الإحالة: <b>" + fm(float(st('rb','100')),'yn') + "</b>\n🎉 هدية الترحيب: <b>" + fm(float(st('wb','50')),'yn') + "</b>\n🎁 هدية يومية: <b>" + fm(float(st('db','10')),'yn') + "</b>\n💎 سعر VIP: <b>" + fm(float(st('vip_price','500')),'yn') + "</b>\n⭐ سعر النجمة: <b>" + fm(float(st('star_rate','50')),'yn') + "</b></blockquote>")
    await c.message.edit_text(txt,reply_markup=KB([[BTN("💵 هامش الربح","smk",s="primary")],[BTN("🎁 مكافأة الإحالة","srb",s="primary")],[BTN("🎉 هدية الترحيب","swb",s="primary")],[BTN("🎁 هدية يومية","sdb",s="primary")],[BTN("💎 سعر VIP","svp",s="primary")],[BTN("⭐ سعر النجمة","ssr",s="primary")],[BTN("🔙 رجوع","admin",s="danger")]]))

@dp.callback_query(F.data == "smk")
async def smk(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"smk")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("هامش الربح","💵") + "\n\n<blockquote>✍️ أرسل القيمة</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data == "srb")
async def srb(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"srb")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("مكافأة الإحالة","🎁") + "\n\n<blockquote>✍️ أرسل القيمة</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data == "swb")
async def swb(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"swb")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("هدية الترحيب","🎉") + "\n\n<blockquote>✍️ أرسل القيمة</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data == "sdb")
async def sdb(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"sdb")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("هدية يومية","🎁") + "\n\n<blockquote>✍️ أرسل القيمة</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data == "svp")
async def svp(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"svp")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("سعر VIP","💎") + "\n\n<blockquote>✍️ أرسل السعر</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data == "ssr")
async def ssr(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"ssr")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("سعر النجمة","⭐") + "\n\n<blockquote>✍️ كم رصيد تعطي النجمة الواحدة؟\nمثال: 50 يعني 50 ر.ي قديم = 1 نجمة</blockquote>",reply_markup=ForceReply(selective=True))

# ═══════════ أسعار الصرف ═══════════
@dp.callback_query(F.data == "art")
async def art(c:CallbackQuery):
    if not ia(c.from_user.id): return
    r = []
    for k,(f,n,s,_) in CUR.items(): r.append([BTN(f+" "+n+" = "+str(rate(k)),"ert_"+k,s="primary")])
    r.append([BTN("🔙 رجوع","admin",s="danger")])
    await c.message.edit_text(hd2("أسعار الصرف","💱") + "\n\n<blockquote>💠 كم وحدة = 1 ريال يمني قديم</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data.startswith("ert_"))
async def ert(c:CallbackQuery):
    if not ia(c.from_user.id): return
    k = c.data[4:]
    if k not in CUR: return
    ss(c.from_user.id,"ert",k)
    f,n,s,r_ = CUR[k]
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("تعديل سعر","💱") + "\n\n  💠 " + f + " <b>" + n + "</b>\n  💵 الحالي: <b>" + str(rate(k)) + "</b>\n\n  <blockquote>✍️ أرسل السعر الجديد</blockquote>",reply_markup=ForceReply(selective=True))

# ═══════════ أسعار النجمة ═══════════
@dp.callback_query(F.data == "asr")
async def asr(c:CallbackQuery):
    if not ia(c.from_user.id): return
    r = float(st("star_rate","50"))
    await c.message.edit_text(hd2("⭐ سعر النجمة","💫") + "\n\n  <blockquote>💠 سعر النجمة الحالي: <b>" + fm(r,'yn') + "</b>\n\n⭐ النجمة الواحدة في تلجرام = " + fm(r,'yn') + "</blockquote>" + footer(c.from_user.id), reply_markup=KB([[BTN("✏️ تعديل السعر","ssr",s="primary")],[BTN("🔙 رجوع","admin",s="danger")]]))

# ═══════════ الكوبونات ═══════════
@dp.callback_query(F.data == "acp")
async def acp(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    cps = c2.execute("SELECT * FROM cps").fetchall()
    c2.close()
    t = hd2("الكوبونات","🎟️") + "\n\n  <blockquote>"
    if not cps: t += "💠 لا توجد"
    for cp in cps: t += "🎟️ <code>" + cp['cd'] + "</code> | " + str(cp['dsc']) + "% | " + str(cp['us']) + "/" + str(cp['mx']) + "\n"
    t += "</blockquote>"
    await c.message.edit_text(t,reply_markup=KB([[BTN("➕ إضافة كوبون","acd",s="success")],[BTN("🔙 رجوع","admin",s="danger")]]))

@dp.callback_query(F.data == "acd")
async def acd(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"acd")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("إضافة كوبون","➕") + "\n\n<blockquote>✍️ الصيغة:\n<code>الكود النسبة الحد</code>\n\nمثال:\n<code>SAVE20 20 100</code></blockquote>",reply_markup=ForceReply(selective=True))

