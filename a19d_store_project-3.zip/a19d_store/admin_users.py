# -*- coding: utf-8 -*-
"""معالجات بوت A19d Store — جزء من المشروع المقسّم."""
from .core import *  # مشاركة الإعدادات والدوال الأساسية مع المعالجات

# ═══════════ المستخدمون ═══════════
@dp.callback_query(F.data == "au")
async def au(c:CallbackQuery):
    if not ia(c.from_user.id): return
    c2 = db()
    us = c2.execute("SELECT * FROM users ORDER BY id DESC LIMIT 15").fetchall()
    c2.close()
    r = []
    for u in us:
        s = "🚫" if u['bn'] else ("👑" if u['vip'] else "✅")
        r.append([BTN(s+" "+u['fn'][:15]+" | "+str(u['id']),"us_"+str(u['id']),s="primary")])
    r.append([BTN("🔍 بحث","aus",s="success")])
    r.append([BTN("🔙 رجوع","admin",s="danger")])
    await c.message.edit_text(hd2("المستخدمون","👥") + "\n\n<blockquote>💠 اضغط للإدارة</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data == "aus")
async def aus(c:CallbackQuery):
    if not ia(c.from_user.id): return
    ss(c.from_user.id,"aus")
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("بحث","🔍") + "\n\n<blockquote>✍️ أرسل ID أو @username</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data.startswith("us_"))
async def us(c:CallbackQuery):
    if not ia(c.from_user.id): return
    try: uid = int(c.data[3:])
    except: return
    u = gu(uid)
    c2 = db()
    oc = c2.execute("SELECT COUNT(*) FROM ords WHERE uid=?",(uid,)).fetchone()[0]
    c2.close()
    cur = u.get('cur') or BASE
    t = (hd2("مستخدم #"+str(uid),"👤") + "\n\n  <blockquote>👤 " + u['fn'] + vrb(u.get('vr')) + "\n🆔 <code>" + str(uid) + "</code>\n💱 " + cn(cur) + "\n💰 " + fm(u['b'],cur) + "\n⭐ " + str(u['pt']) + "\n🎁 " + str(u['rc']) + " إحالة\n📦 " + str(oc) + " طلب\n🎖️ " + ach_txt(oc) + "\n👑 " + vb(u['vip']) + "\n📊 " + sb(u['bn']) + "</blockquote>")
    r = [
        [BTN("💰 شحن","uc_"+str(uid),s="success"),BTN("⭐ نقاط","up_"+str(uid),s="primary")],
        [BTN("🚫 حظر" if not u['bn'] else "✅ فك","ub_"+str(uid),s="danger" if not u['bn'] else "success")],
        [BTN("👑 VIP" if not u['vip'] else "👤 إزالة","uv_"+str(uid),s="primary")],
        [BTN("✉️ رسالة","um_"+str(uid),s="primary")],
        [BTN("🔙 رجوع","au",s="danger")],
    ]
    await c.message.edit_text(t,reply_markup=KB(r))

@dp.callback_query(F.data.startswith("uc_"))
async def uc(c:CallbackQuery):
    if not ia(c.from_user.id): return
    uid = int(c.data[3:])
    ss(c.from_user.id,"uc",str(uid))
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("شحن رصيد","💰") + "\n\n<blockquote>✍️ أرسل المبلغ</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data.startswith("up_"))
async def up_(c:CallbackQuery):
    if not ia(c.from_user.id): return
    uid = int(c.data[3:])
    ss(c.from_user.id,"up",str(uid))
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("إضافة نقاط","⭐") + "\n\n<blockquote>✍️ أرسل عدد النقاط</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data.startswith("ub_"))
async def ub(c:CallbackQuery):
    if not ia(c.from_user.id): return
    uid = int(c.data[3:])
    c2 = db()
    u = c2.execute("SELECT bn FROM users WHERE id=?",(uid,)).fetchone()
    if u:
        n = 0 if u['bn'] else 1
        c2.execute("UPDATE users SET bn=? WHERE id=?",(n,uid)); c2.commit()
        try:
            if n: await bot.send_message(uid,hd2("🚫 تم حظرك","🚫"))
            else: await bot.send_message(uid,hd2("✅ تم فك الحظر","✅"))
        except: pass
    c2.close()
    c.data = "us_"+str(uid)
    await us(c)

@dp.callback_query(F.data.startswith("uv_"))
async def uv(c:CallbackQuery):
    if not ia(c.from_user.id): return
    uid = int(c.data[3:])
    c2 = db()
    u = c2.execute("SELECT vip FROM users WHERE id=?",(uid,)).fetchone()
    if u:
        n = 0 if u['vip'] else 1
        c2.execute("UPDATE users SET vip=? WHERE id=?",(n,uid)); c2.commit()
    c2.close()
    c.data = "us_"+str(uid)
    await us(c)

@dp.callback_query(F.data.startswith("um_"))
async def um(c:CallbackQuery):
    if not ia(c.from_user.id): return
    uid = int(c.data[3:])
    ss(c.from_user.id,"um",str(uid))
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("رسالة","✉️") + "\n\n<blockquote>✍️ أرسل الرسالة</blockquote>",reply_markup=ForceReply(selective=True))

