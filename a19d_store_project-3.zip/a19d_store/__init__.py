"""A19d Store Telegram bot package."""
