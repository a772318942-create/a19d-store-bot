# -*- coding: utf-8 -*-
"""معالجات بوت A19d Store — جزء من المشروع المقسّم."""
from .core import *  # مشاركة الإعدادات والدوال الأساسية مع المعالجات

# ═══════════ إدارة المنتجات ═══════════
@dp.callback_query(F.data == "ap")
async def ap(c:CallbackQuery):
    if not ia(c.from_user.id): return
    await c.message.edit_text(hd2("إدارة المنتجات","📦") + "\n\n<blockquote>💠 اختر</blockquote>",reply_markup=KB([[BTN("➕ إضافة منتج","adp",s="success")],[BTN("📋 عرض المنتجات","amp",s="primary")],[BTN("🔙 رجوع","admin",s="danger")]]))

@dp.callback_query(F.data == "adp")
async def adp(c:CallbackQuery):
    if not ia(c.from_user.id): return
    r = []
    for k,(e,n,_) in MC.items(): r.append([BTN(e+" "+n,"adm_"+k,s="primary")])
    r.append([BTN("🔙 رجوع","admin",s="danger")])
    await c.message.edit_text(hd2("إضافة منتج","➕") + "\n\n<blockquote>💠 اختر القسم</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data.startswith("adm_"))
async def adm_mc(c:CallbackQuery):
    if not ia(c.from_user.id): return
    k = c.data[4:]
    if k not in MC: return
    r = []
    for sk,n in SC[k].items(): r.append([BTN(n,"ams_"+k+"_"+sk,s="primary")])
    r.append([BTN("🔙 رجوع","adp",s="danger")])
    await c.message.edit_text(hd2("إضافة منتج","➕") + "\n\n<blockquote>💠 اختر القسم الفرعي</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data.startswith("ams_"))
async def ams(c:CallbackQuery):
    if not ia(c.from_user.id): return
    p = c.data.split("_",2)
    m,sub = p[1],p[2]
    ss(c.from_user.id,"wnm",m+"|"+sub)
    n = SC[m][sub]
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("خطوة 1/6: الاسم","📝") + "\n\n  📂 القسم: <b>" + n + "</b>\n\n  <blockquote>✍️ أرسل <b>اسم المنتج</b></blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data == "amp")
async def amp(c:CallbackQuery):
    if not ia(c.from_user.id): return
    r = []
    for k,(e,n,_) in MC.items(): r.append([BTN(e+" "+n,"mmp_"+k,s="primary")])
    r.append([BTN("🔙 رجوع","admin",s="danger")])
    await c.message.edit_text(hd2("المنتجات","📋") + "\n\n<blockquote>💠 اختر القسم</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data.startswith("mmp_"))
async def mmp(c:CallbackQuery):
    if not ia(c.from_user.id): return
    k = c.data[4:]
    if k not in MC: return
    r = []
    for sk,n in SC[k].items(): r.append([BTN(n,"mms_"+k+"_"+sk,s="primary")])
    r.append([BTN("🔙 رجوع","amp",s="danger")])
    await c.message.edit_text(hd2("المنتجات","📋") + "\n\n<blockquote>💠 اختر القسم الفرعي</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data.startswith("mms_"))
async def mms(c:CallbackQuery):
    if not ia(c.from_user.id): return
    p = c.data.split("_",2)
    m,sub = p[1],p[2]
    c2 = db()
    ps = c2.execute("SELECT * FROM prods WHERE mc=? AND sc=?",(m,sub)).fetchall()
    c2.close()
    n = SC[m][sub]
    if not ps: await alert(c,"📭 لا توجد منتجات"); return
    r = []
    for p2 in ps:
        st_ = "✅" if p2['act'] else "🚫"
        r.append([BTN(st_+" #"+str(p2['id'])+" "+p2['nm'][:25],"ep_"+str(p2['id']),s="primary")])
    r.append([BTN("🔙 رجوع","mmp_"+m,s="danger")])
    await c.message.edit_text(hd2("منتجات "+n,"📋") + "\n\n<blockquote>💠 اضغط للتعديل</blockquote>",reply_markup=KB(r))

@dp.callback_query(F.data.startswith("ep_"))
async def ep(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[3:])
    c2 = db()
    p = c2.execute("SELECT * FROM prods WHERE id=?",(pid,)).fetchone()
    c2.close()
    if not p: return
    f = p['pr'] + mk()
    stk = "♾️" if p['stk']<0 else str(p['stk'])
    md = []
    if p['img']: md.append("🖼️")
    if p['lnk']: md.append("🔗")
    if p['vid']: md.append("🎬")
    if p['fid']: md.append("📎")
    mt = " ".join(md) if md else "❌"
    t = (hd2("منتج #"+str(p['id']),"📦") + "\n\n  <blockquote>📦 <b>" + p['nm'] + "</b>\n📝 " + p['ds'][:80] + "\n\n💰 السعر: " + fm(p['pr'],'yn') + "\n💵 النهائي: " + fm(f,'yn') + "\n📦 المخزون: " + stk + "\n🔥 المبيعات: " + str(p['sold']) + "\n⭐ التقييم: " + (stars(p['rt'])+" ("+str(p['rcnt'])+")" if p['rcnt']>0 else "لا") + "\n⚡ " + ("✅" if p['act'] else "🚫") + "\n📎 " + mt + "</blockquote>")
    r = [
        [BTN("💰 السعر","epr_"+str(pid),s="primary"),BTN("📦 المخزون","est_"+str(pid),s="primary")],
        [BTN("✏️ الوصف","eds_"+str(pid),s="primary"),BTN("✏️ الاسم","enm_"+str(pid),s="primary")],
        [BTN("🖼️ الصورة","eim_"+str(pid),s="primary"),BTN("🔗 الرابط","elnk_"+str(pid),s="primary")],
        [BTN("🎬 الفيديو","evd_"+str(pid),s="primary"),BTN("📎 الملف","efl_"+str(pid),s="primary")],
        [BTN("👁️ معاينة","epv_"+str(pid),s="primary")],
        [BTN("🔄 تبديل","etg_"+str(pid),s="success"),BTN("🗑️ حذف","edl_"+str(pid),s="danger")],
        [BTN("🔙 رجوع","mms_"+p['mc']+"_"+p['sc'],s="danger")],
    ]
    await c.message.edit_text(t,reply_markup=KB(r))

@dp.callback_query(F.data.startswith("epv_"))
async def epv(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    c2 = db()
    p = c2.execute("SELECT * FROM prods WHERE id=?",(pid,)).fetchone()
    c2.close()
    if not p: return
    f = p['pr'] + mk()
    cap = (hd2("معاينة","👁️") + "\n\n  💠 <b>" + p['nm'] + "</b>\n\n  <blockquote>📝 " + p['ds'] + "\n\n💰 " + fm(f,'yn') + (("\n🔗 " + p['lnk']) if p['lnk'] else "") + "</blockquote>")
    try: await c.message.delete()
    except: pass
    if p['img']:
        try: await c.message.answer_photo(p['img'],caption=cap,reply_markup=KB([[BTN("🔙 رجوع","ep_"+str(pid),s="danger")]]))
        except: await c.message.answer(cap,reply_markup=KB([[BTN("🔙 رجوع","ep_"+str(pid),s="danger")]]))
    else: await c.message.answer(cap,reply_markup=KB([[BTN("🔙 رجوع","ep_"+str(pid),s="danger")]]))

@dp.callback_query(F.data.startswith("etg_"))
async def etg(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    c2 = db()
    p = c2.execute("SELECT act FROM prods WHERE id=?",(pid,)).fetchone()
    if p:
        c2.execute("UPDATE prods SET act=? WHERE id=?",(0 if p['act'] else 1,pid)); c2.commit()
    c2.close()
    c.data = "ep_"+str(pid)
    await ep(c)

@dp.callback_query(F.data.startswith("edl_"))
async def edl(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    c2 = db(); c2.execute("DELETE FROM prods WHERE id=?",(pid,)); c2.commit(); c2.close()
    await c.message.edit_text(hd2("تم الحذف","✅") + "\n\n<blockquote>تم حذف المنتج</blockquote>",reply_markup=adm_kb())

@dp.callback_query(F.data.startswith("epr_"))
async def epr(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    ss(c.from_user.id,"epr",str(pid))
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("تعديل السعر","💰") + "\n\n<blockquote>✍️ أرسل السعر الجديد</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data.startswith("est_"))
async def est(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    ss(c.from_user.id,"est",str(pid))
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("تعديل المخزون","📦") + "\n\n<blockquote>✍️ أرسل الكمية (-1 لبلا حدود)</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data.startswith("eds_"))
async def eds(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    ss(c.from_user.id,"eds",str(pid))
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("تعديل الوصف","✏️") + "\n\n<blockquote>✍️ أرسل الوصف</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data.startswith("enm_"))
async def enm(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    ss(c.from_user.id,"enm",str(pid))
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("تعديل الاسم","✏️") + "\n\n<blockquote>✍️ أرسل الاسم</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data.startswith("elnk_"))
async def elnk(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[5:])
    ss(c.from_user.id,"elnk",str(pid))
    try: await c.message.delete()
    except: pass
    await c.message.answer(hd2("تعديل الرابط","🔗") + "\n\n<blockquote>✍️ أرسل الرابط الجديد\n(اترك فارغاً لإزالة الرابط — أرسل -)</blockquote>",reply_markup=ForceReply(selective=True))

@dp.callback_query(F.data.startswith("eim_"))
async def eim(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    ss(c.from_user.id,"eim",str(pid))
    await c.message.edit_text(hd2("تعديل الصورة","🖼️") + "\n\n<blockquote>✍️ أرسل الصورة</blockquote>",reply_markup=KB([[BTN("❌ إلغاء","admin",s="danger")]]))

@dp.callback_query(F.data.startswith("evd_"))
async def evd(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    ss(c.from_user.id,"evd",str(pid))
    await c.message.edit_text(hd2("تعديل الفيديو","🎬") + "\n\n<blockquote>✍️ أرسل الفيديو</blockquote>",reply_markup=KB([[BTN("❌ إلغاء","admin",s="danger")]]))

@dp.callback_query(F.data.startswith("efl_"))
async def efl(c:CallbackQuery):
    if not ia(c.from_user.id): return
    pid = int(c.data[4:])
    ss(c.from_user.id,"efl",str(pid))
    await c.message.edit_text(hd2("تعديل الملف","📎") + "\n\n<blockquote>✍️ أرسل الملف</blockquote>",reply_markup=KB([[BTN("❌ إلغاء","admin",s="danger")]]))

