# -*- coding: utf-8 -*-
"""شغّل البوت باستخدام: python main.py"""
import asyncio
import logging
from a19d_store.app import main

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    asyncio.run(main())
